package com.sadaqa.jariya;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * يضيف بيانات المرحوم (الاسم/الصورة/الأدعية) إلى ملف الـ APK دون إعادة توقيعه.
 *
 * الفكرة: كتلة التوقيع (APK Signing Block) تحوي أزواجًا (رقم ← قيمة)، وتوقيع v2/v3 لا يغطي هذه الكتلة نفسها
 * بل يغطي بقية الملف فقط، لذلك إضافة زوج برقمنا الخاص لا تُبطل التوقيع، والنظام يتجاهل الأرقام التي لا يعرفها.
 * (الأسلوب نفسه الذي تستعمله أدوات "قنوات التوزيع" مثل Walle).
 */
final class ApkPayload {

    static final int ID = 0x53444B31;                 // معرّف زوجنا
    private static final int PADDING_ID = 0x42726577; // حشوة المحاذاة القياسية
    private static final byte[] MAGIC = "APK Sig Block 42".getBytes();
    private static final int MAX_VALUE = 4 * 1024 * 1024;

    private ApkPayload() { }

    /** ملف مقسوم إلى مواضع كتلة التوقيع. */
    private static final class Layout {
        long eocd, cdOffset, cdSize, blockStart, pairsStart, pairsEnd;
    }

    /** يرجع القيمة المخزنة في الـ APK أو null إن لم توجد. */
    static byte[] read(File apk) {
        try (RandomAccessFile f = new RandomAccessFile(apk, "r")) {
            Layout l = layout(f);
            if (l == null) return null;
            long pos = l.pairsStart;
            while (pos + 12 <= l.pairsEnd) {
                long len = le64(f, pos);
                if (len < 4 || pos + 8 + len > l.pairsEnd) return null;
                int id = (int) le32(f, pos + 8);
                if (id == ID) {
                    long vlen = len - 4;
                    if (vlen > MAX_VALUE) return null;
                    byte[] v = new byte[(int) vlen];
                    f.seek(pos + 12);
                    f.readFully(v);
                    return v;
                }
                pos += 8 + len;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** يكتب نسخة من src إلى dst تحوي القيمة. يرجع false إن كان الـ APK بلا كتلة توقيع v2/v3. */
    static boolean write(File src, File dst, byte[] value) {
        if (value == null || value.length > MAX_VALUE) return false;
        try (RandomAccessFile f = new RandomAccessFile(src, "r")) {
            Layout l = layout(f);
            if (l == null) return false;

            // 1) أزواج الكتلة الحالية، بعد حذف زوجنا القديم وحشوة المحاذاة
            List<byte[]> keep = new ArrayList<>();
            long pos = l.pairsStart;
            while (pos + 12 <= l.pairsEnd) {
                long len = le64(f, pos);
                if (len < 4 || pos + 8 + len > l.pairsEnd) return false;
                int id = (int) le32(f, pos + 8);
                if (id != ID && id != PADDING_ID) {
                    byte[] b = new byte[(int) (8 + len)];
                    f.seek(pos);
                    f.readFully(b);
                    keep.add(b);
                }
                pos += 8 + len;
            }
            long pairsLen = 0;
            for (byte[] b : keep) pairsLen += b.length;
            byte[] mine = pair(ID, value);
            pairsLen += mine.length;

            // 2) حشوة تجعل نهاية الكتلة (بداية الدليل المركزي) من مضاعفات 4096 كما يفعل apksigner
            long end = l.blockStart + 8 + pairsLen + 24;
            long pad = (4096 - (end % 4096)) % 4096;
            if (pad != 0 && pad < 12) pad += 4096;
            byte[] padPair = pad == 0 ? new byte[0] : pair(PADDING_ID, new byte[(int) (pad - 12)]);
            pairsLen += padPair.length;
            long blockSize = pairsLen + 24;          // لا يشمل حقل الحجم الأول
            long newCdOffset = l.blockStart + 8 + blockSize;

            // 3) الكتابة: [المحتوى] [الكتلة الجديدة] [الدليل المركزي] [EOCD بعد تعديل موضع الدليل]
            try (OutputStream out = new FileOutputStream(dst)) {
                copy(f, 0, l.blockStart, out);
                out.write(le64Bytes(blockSize));
                for (byte[] b : keep) out.write(b);
                out.write(mine);
                out.write(padPair);
                out.write(le64Bytes(blockSize));
                out.write(MAGIC);
                copy(f, l.cdOffset, l.eocd, out);                    // الدليل المركزي (وما قبل EOCD)
                long eocdLen = f.length() - l.eocd;
                byte[] eocd = new byte[(int) eocdLen];
                f.seek(l.eocd);
                f.readFully(eocd);
                ByteBuffer.wrap(eocd).order(ByteOrder.LITTLE_ENDIAN).putInt(16, (int) newCdOffset);
                out.write(eocd);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------- تفاصيل الملف ----------------------------

    private static Layout layout(RandomAccessFile f) throws IOException {
        long len = f.length();
        int max = (int) Math.min(len, 65535 + 22);
        if (max < 22) return null;
        byte[] buf = new byte[max];
        f.seek(len - max);
        f.readFully(buf);
        ByteBuffer bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
        long eocd = -1;
        for (int i = max - 22; i >= 0; i--) {
            if (buf[i] == 0x50 && buf[i + 1] == 0x4b && buf[i + 2] == 0x05 && buf[i + 3] == 0x06) {
                int comment = bb.getShort(i + 20) & 0xFFFF;
                if (i + 22 + comment == max) { eocd = len - max + i; break; }
            }
        }
        if (eocd < 0) return null;
        Layout l = new Layout();
        l.eocd = eocd;
        l.cdSize = le32(f, eocd + 12);
        l.cdOffset = le32(f, eocd + 16);
        if (l.cdOffset < 32 || l.cdOffset + l.cdSize > eocd) return null;

        byte[] tail = new byte[24];
        f.seek(l.cdOffset - 24);
        f.readFully(tail);
        for (int i = 0; i < 16; i++) if (tail[8 + i] != MAGIC[i]) return null;   // لا توجد كتلة توقيع
        long size = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).getLong(0);
        if (size < 24 || size > l.cdOffset - 8) return null;
        l.blockStart = l.cdOffset - size - 8;
        if (le64(f, l.blockStart) != size) return null;
        l.pairsStart = l.blockStart + 8;
        l.pairsEnd = l.cdOffset - 24;
        return l;
    }

    private static byte[] pair(int id, byte[] value) {
        ByteBuffer b = ByteBuffer.allocate(12 + value.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putLong(4L + value.length);
        b.putInt(id);
        b.put(value);
        return b.array();
    }

    private static void copy(RandomAccessFile f, long from, long to, OutputStream out) throws IOException {
        byte[] buf = new byte[65536];
        f.seek(from);
        long left = to - from;
        while (left > 0) {
            int n = f.read(buf, 0, (int) Math.min(buf.length, left));
            if (n < 0) throw new IOException("eof");
            out.write(buf, 0, n);
            left -= n;
        }
    }

    private static long le32(RandomAccessFile f, long pos) throws IOException {
        byte[] b = new byte[4];
        f.seek(pos);
        f.readFully(b);
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt() & 0xFFFFFFFFL;
    }

    private static long le64(RandomAccessFile f, long pos) throws IOException {
        byte[] b = new byte[8];
        f.seek(pos);
        f.readFully(b);
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    private static byte[] le64Bytes(long v) {
        return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array();
    }
}
