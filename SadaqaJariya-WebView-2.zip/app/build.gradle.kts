import java.util.Properties

plugins { id("com.android.application") }

val ks = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val hasKs = ks.containsKey("storeFile")

android {
    namespace = "com.sadaqa.jariya"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sadaqa.jariya"
        minSdk = 21            // أندرويد 5.0 فما فوق (يغطي تقريبًا كل الهواتف العاملة)
        targetSdk = 34         // يعمل بشكل سليم على أندرويد 14 وما بعده
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        if (hasKs) create("release") {
            storeFile = rootProject.file(ks["storeFile"] as String)
            storePassword = ks["storePassword"] as String
            keyAlias = ks["keyAlias"] as String
            keyPassword = ks["keyPassword"] as String
            enableV1Signing = true   // للهواتف القديمة
            enableV2Signing = true
            enableV3Signing = true
        }
    }

    buildTypes {
        release {
            // الكود صغير؛ إيقاف التصغير يتجنب أي أعطال في جسر JavaScript
            isMinifyEnabled = false
            isShrinkResources = false
            if (hasKs) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint { abortOnError = false; checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.core:core:1.12.0")   // FileProvider فقط
}
