(function () {
  'use strict';
  var N = window.Native || null;
  var CFG = window.CFG || {}, DATA = window.DATA || {};

  var NAMES = ['النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس'];
  var COUNTS = [40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
  // صفحة بداية كل سورة في مصحف المدينة (جزء عمّ: 582 → 604)
  var START = [582,583,585,586,587,587,589,590,591,591,592,593,594,595,595,596,596,597,597,598,598,599,599,600,600,601,601,601,602,602,602,603,603,603,604,604,604];
  var FIRST = 582, LAST = 604;
  var READERS = [
    { id: 'abdulbasit', name: 'الشيخ عبد الباسط عبد الصمد', tag: 'مُجَوَّد' },
    { id: 'ajami', name: 'الشيخ أحمد علي العجمي', tag: '' },
    { id: 'minshawi', name: 'الشيخ محمد صديق المنشاوي', tag: 'مُجَوَّد' }
  ];
  var TITLES = { azkar: '🌅 أذكار الصباح والمساء', hisn: '🛡️ حصن المسلم', hadith: '📜 الأحاديث النبوية' };

  var $app = document.getElementById('app');
  var stack = [{ v: 'home' }];
  var audio = { mode: 'idle', listId: '', ayah: -1, msg: '' };
  var reader = store('reader') || 'abdulbasit';
  var night = store('night') === '1';
  var duaItems = [];
  var toastT = null;
  var photoV = 0;

  function conf(k) { var v = store('cfg_' + k); return (v && v.trim()) ? v : (CFG[k] || ''); }
  function userAudio() {
    var out = [];
    try { JSON.parse(store('cfg_audio') || '[]').forEach(function (a, i) { if (a.url && /^https:\/\//.test(a.url)) out.push({ id: 'u' + i, title: a.title || ('دعاء صوتي ' + ar(i + 1)), src: a.url }); }); } catch (e) { }
    return out;
  }
  function shareText() { return 'صدقة جارية لروح المرحوم ' + conf('name') + '، ثبّت التطبيق وشاركه ليصله الأجر بإذن الله 🤲'; }

  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ar(n) { return String(n).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.charAt(d); }); }
  function nat(fn) { try { if (N && typeof N[fn] === 'function') return N[fn].apply(N, [].slice.call(arguments, 1)); } catch (e) { } }
  function $(id) { return document.getElementById(id); }
  function cur() { return stack[stack.length - 1]; }
  function rname(id) { for (var i = 0; i < READERS.length; i++) if (READERS[i].id === id) return READERS[i].name; return ''; }
  function toast(m) { var t = $('toast'); if (!t) return; t.textContent = m; t.className = 'show'; clearTimeout(toastT); toastT = setTimeout(function () { t.className = ''; }, 3800); }

  // ---------------- الواجهات ----------------
  function head(title) { return '<header><button class="ib" data-a="back" aria-label="رجوع">→</button><h2>' + esc(title) + '</h2></header>'; }
  function btn(attrs, ic, label, cls) { return '<button class="btn ' + (cls || '') + '" ' + attrs + '><span class="ic">' + ic + '</span><span>' + label + '</span></button>'; }

  function vHome() {
    return '<div class="hero"><div class="ring"><img src="' + (nat('photoUrl') || 'img/photo_face.jpg') + '" alt="" onerror="this.onerror=null;this.src=\'img/photo_face.jpg\'"></div>' +
      '<p class="kicker">' + esc(conf('title')) + '</p><h1>' + esc(conf('name')) + '</h1>' +
      '<div class="dua-box">' + esc(conf('dua')) + '</div></div>' +
      '<nav class="menu">' +
      btn('data-a="share"', '📤', 'شارك التطبيق لزيادة الأجر', 'gold') +
      '<button class="sub" data-a="sharezip">إن رفضت الرسائل ملف التطبيق: شاركه مضغوطًا (ZIP)</button>' +
      btn('data-a="go" data-v="juz"', '📗', 'جزء عمّ (قراءة واستماع)') +
      btn('data-a="go" data-v="dua"', '🤲', 'أدعية للميت') +
      btn('data-a="go" data-v="list" data-k="azkar"', '🌅', 'أذكار الصباح والمساء') +
      btn('data-a="go" data-v="list" data-k="hisn"', '🛡️', 'حصن المسلم') +
      btn('data-a="go" data-v="list" data-k="hadith"', '📜', 'الأحاديث النبوية') +
      btn('data-a="go" data-v="edit"', '✏️', 'تعديل الاسم والصورة والدعاء') +
      '</nav>';
  }

  function vList(k) {
    var h = head(TITLES[k] || ''), items = DATA[k] || [];
    return h + items.map(function (i) { return '<div class="card"><h4>' + esc(i.t) + '</h4><p>' + esc(i.x) + '</p></div>'; }).join('');
  }

  function vDua() {
    duaItems = (CFG.duaAudio || []).filter(function (d) {
      return d.src.indexOf('asset:') !== 0 || nat('hasAsset', d.src.substring(6)) === true;
    }).concat(userAudio());
    var h = head('🤲 أدعية للميت') + '<h3 class="sec">🎧 أدعية صوتية</h3>';
    if (duaItems.length) {
      h += duaItems.map(function (d, i) {
        return '<button class="track" data-a="dua" data-i="' + i + '" id="tr' + d.id + '"><span>' + esc(d.title) + '</span><span class="pl">▶</span></button>';
      }).join('');
    } else {
      h += '<p class="note">الأدعية الصوتية ستتوفر قريبًا بإذن الله</p>';
    }
    h += '<h3 class="sec">📖 أدعية مكتوبة</h3>';
    h += (DATA.dua || []).map(function (i) { return '<div class="card"><h4>' + esc(i.t) + '</h4><p>' + esc(i.x) + '</p></div>'; }).join('');
    return h;
  }

  function audioFields() {
    var cur_ = [];
    try { cur_ = JSON.parse(store('cfg_audio') || '[]'); } catch (e) { }
    var h = '';
    for (var i = 0; i < 3; i++) {
      var a = cur_[i] || {};
      h += '<input id="a_t' + i + '" type="text" maxlength="50" placeholder="عنوان الدعاء ' + ar(i + 1) + '" value="' + esc(a.title || '') + '">' +
           '<input id="a_u' + i + '" type="text" dir="ltr" placeholder="https://.../dua.mp3" value="' + esc(a.url || '') + '">';
    }
    return h;
  }

  function vEdit() {
    return head('✏️ تعديل بيانات المرحوم') +
      '<div class="card edit"><div class="ring sm"><img id="ep" src="' + (nat('photoUrl') || 'img/photo_face.jpg') + '" alt=""></div>' +
      '<button class="btn" data-a="pick"><span class="ic">🖼️</span><span>اختيار صورة من الهاتف</span></button>' +
      '<label>العبارة فوق الاسم</label><input id="f_title" type="text" maxlength="60" value="' + esc(conf('title')) + '">' +
      '<label>الاسم</label><input id="f_name" type="text" maxlength="60" value="' + esc(conf('name')) + '">' +
      '<label>الدعاء</label><textarea id="f_dua" rows="4" maxlength="300">' + esc(conf('dua')) + '</textarea>' +
      '<label>أدعية صوتية: رابط mp3 مباشر (https) يُحمَّل مرة واحدة ثم يُحفظ</label>' + audioFields() +
      '<button class="btn gold" data-a="savecfg"><span class="ic">💾</span><span>حفظ</span></button>' +
      '<button class="btn" data-a="resetcfg"><span class="ic">↩️</span><span>استرجاع الاسم والصورة الأصليين</span></button></div>' +
      '<p class="note">التعديل يُحفظ على هذا الهاتف فقط. النسخة التي تشاركها تحمل البيانات الأصلية للتطبيق.</p>';
  }

  function chips() {
    return '<div class="chips">' + READERS.map(function (r) {
      return '<button class="chip' + (r.id === reader ? ' on' : '') + '" data-a="reader" data-id="' + r.id + '">' + esc(r.name) + (r.tag ? '<small>' + r.tag + '</small>' : '') + '</button>';
    }).join('') + '</div>';
  }

  function vJuz() {
    var h = head('📗 جزء عمّ') + '<h3 class="sec">اختر القارئ</h3>' + chips() + '<div class="card dl" id="dl">' + dlHtml() + '</div><h3 class="sec">السور</h3>';
    for (var i = 0; i < NAMES.length; i++) {
      h += '<button class="srow" data-a="surah" data-i="' + i + '"><span class="num">' + ar(78 + i) + '</span><span class="nm">سورة ' + NAMES[i] + '</span><span class="cnt">' + ar(COUNTS[i]) + ' آية</span></button>';
    }
    h += '<div class="foot"><button data-a="clear">مسح التلاوات المحفوظة على الجهاز (<span id="cs">' + (nat('cacheInfo') || '0') + '</span> م.ب)</button></div>';
    return h;
  }

  var dlS = { state: 'idle', done: 0, total: 565 };
  function dlHtml() {
    var have = nat('cachedCount', reader) || 0, tot = 565;
    if (dlS.state === 'run') {
      return '<p class="dlt">جارٍ التحميل… ' + ar(dlS.done) + ' من ' + ar(dlS.total) + '</p><div class="pb"><i style="width:' + Math.round(dlS.done * 100 / dlS.total) + '%"></i></div>' +
             '<button class="btn" data-a="dlcancel"><span class="ic">⏹</span><span>إيقاف التحميل</span></button>';
    }
    if (have >= tot) return '<p class="dlt">✅ جزء عمّ محمّل كاملاً بصوت هذا القارئ، ويعمل دون إنترنت</p>';
    return '<p class="dlt">للاستماع دون إنترنت: حمّل جزء عمّ كاملاً مرة واحدة (' + ar(have) + ' من ' + ar(tot) + ' محمّل). يُفضَّل الاتصال بشبكة Wi-Fi.</p>' +
           '<button class="btn gold" data-a="dlstart"><span class="ic">⬇️</span><span>تحميل جزء عمّ لهذا القارئ</span></button>';
  }
  window.onDl = function (o) {
    dlS = { state: o.state === 'run' ? 'run' : 'idle', done: o.done, total: o.total };
    if (o.state === 'fail') toast('توقف التحميل. تحقق من الإنترنت ثم أعد المحاولة (يكمل من حيث توقف)');
    if (o.state === 'done') toast('تم تحميل جزء عمّ كاملاً ✅');
    var d = $('dl'); if (d && cur().v === 'juz') d.innerHTML = dlHtml();
  };

  function vPages(s) {
    var i = s.i, p = s.p;
    return head('سورة ' + NAMES[i]) +
      '<div class="chips">' + READERS.map(function (r) {
        return '<button class="chip' + (r.id === reader ? ' on' : '') + '" data-a="reader" data-id="' + r.id + '">' + esc(r.name) + (r.tag ? '<small>' + r.tag + '</small>' : '') + '</button>';
      }).join('') + '</div>' +
      btn('data-a="playall"', '▶', 'استماع إلى سورة ' + NAMES[i] + ' كاملة', 'gold') +
      '<div class="pgnav"><button data-a="pnext" id="pn">صفحة تالية ‹</button><span id="pi"></span><button data-a="pprev" id="pp">› صفحة سابقة</button></div>' +
      '<div class="pgwrap' + (night ? ' night' : '') + '" id="pw"></div>' +
      '<div class="foot"><button data-a="night">🌙 تبديل وضع الصفحة (ليلي / نهاري)</button></div>';
  }

  // ---------------- عرض صفحات المصحف ----------------
  function showPage() {
    var s = cur(), p = s.p, w = $('pw');
    if (!w) return;
    $('pi').textContent = 'صفحة ' + ar(p) + ' • من ' + ar(LAST);
    $('pn').disabled = p >= LAST; $('pp').disabled = p <= FIRST;
    var u = nat('pageUrl', p);
    if (u) { w.innerHTML = '<img alt="صفحة ' + p + '" src="' + u + '">'; prefetch(p + 1); prefetch(p - 1); return; }
    w.innerHTML = '<div class="pgmsg"><div><span class="spin" style="border-color:rgba(91,74,20,.3);border-top-color:#5b4a14"></span><br>جارٍ تحميل الصفحة… (مرة واحدة فقط ثم تُحفظ)</div></div>';
    nat('fetchPage', p);
  }
  function prefetch(p) { if (p >= FIRST && p <= LAST && !nat('pageUrl', p)) nat('fetchPage', p); }
  window.onPage = function (p, ok) {
    var s = cur(); if (s.v !== 'pages' || s.p !== p) return;
    if (ok) showPage();
    else { var w = $('pw'); if (w) w.innerHTML = '<div class="pgmsg"><div>تعذّر تحميل الصفحة.<br>تأكد من الإنترنت ثم أعد المحاولة<br><button data-a="retry">إعادة المحاولة</button></div></div>'; }
  };
  function turn(d) { var s = cur(), p = s.p + d; if (p < FIRST || p > LAST) return; s.p = p; showPage(); window.scrollTo(0, 0); }

  // ---------------- الرسم والتنقل ----------------
  function render() {
    var s = cur(), h;
    if (s.v === 'home') h = vHome();
    else if (s.v === 'list') h = vList(s.k);
    else if (s.v === 'dua') h = vDua();
    else if (s.v === 'juz') h = vJuz();
    else if (s.v === 'pages') h = vPages(s);
    else if (s.v === 'edit') h = vEdit();
    $app.innerHTML = '<div class="view">' + h + '</div><div id="bar"></div><div id="toast"></div>';
    window.scrollTo(0, 0);
    if (s.v === 'pages') showPage();
    renderBar();
  }
  function go(s) { stack.push(s); render(); }
  window.appBack = function () { if (stack.length > 1) { stack.pop(); render(); return true; } return false; };

  // ---------------- مشغل الصوت ----------------
  function barLabel() {
    var p = (audio.listId || '').split(':'), t = '', sub = '';
    if (p[0] === 's') {
      var i = parseInt(p[2], 10) - 78;
      t = 'سورة ' + (NAMES[i] || '');
      sub = rname(p[1]) + ' • ' + (audio.ayah > 0 ? 'الآية ' + ar(audio.ayah) + ' من ' + ar(COUNTS[i]) : 'البسملة');
    } else if (p[0] === 'm') {
      duaItems.forEach(function (d) { if (d.id === p[1]) t = d.title; });
      sub = 'دعاء صوتي';
    }
    if (audio.mode === 'loading') sub += ' • جارٍ التحميل…';
    return { t: t, s: sub };
  }
  function renderBar() {
    var b = $('bar'); if (!b) return;
    if (audio.mode === 'idle') { b.className = ''; b.innerHTML = ''; syncTracks(); return; }
    var l = barLabel();
    b.className = 'on';
    b.innerHTML = '<div class="inf"><div class="t">' + esc(l.t) + '</div><div class="s">' + esc(l.s) + '</div></div>' +
      '<div class="ctl"><button data-a="aprev" aria-label="السابق">⏮</button>' +
      '<button class="pp" data-a="toggle" aria-label="تشغيل/إيقاف">' + (audio.mode === 'loading' ? '<span class="spin"></span>' : audio.mode === 'playing' ? '⏸' : '▶') + '</button>' +
      '<button data-a="anext" aria-label="التالي">⏭</button><button data-a="astop" aria-label="إيقاف">⏹</button></div>';
    syncTracks();
  }
  function syncTracks() {
    duaItems.forEach(function (d) {
      var el = $('tr' + d.id); if (!el) return;
      var on = audio.listId === 'm:' + d.id && audio.mode !== 'idle';
      el.className = 'track' + (on ? ' on' : '');
      el.lastChild.textContent = on && audio.mode === 'playing' ? '⏸' : '▶';
    });
  }
  window.onAudio = function (o) { audio = o; if (o.msg) toast(o.msg); renderBar(); };
  window.onResumeApp = function () { try { var st = nat('state'); if (st) window.onAudio(JSON.parse(st)); } catch (e) { } };
  window.onPhoto = function (ok) {
    if (!ok) return;
    var e = $('ep'); if (e) e.src = nat('photoUrl') || 'img/photo_face.jpg';
    toast('تم تحديث الصورة');
  };
  window.onCache = function () { var c = $('cs'); if (c) c.textContent = nat('cacheInfo') || '0'; };

  function playSurah(i, ayah) { if (!N) return toast('الاستماع متاح داخل التطبيق فقط'); nat('playSurah', reader, 78 + i, ayah || 0); }

  // ---------------- الأحداث ----------------
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-a]') : null; if (!el) return;
    var a = el.getAttribute('data-a'), s = cur();
    switch (a) {
      case 'back': window.appBack(); break;
      case 'share': if (N) nat('shareApk', shareText(), false); else toast('المشاركة متاحة داخل التطبيق فقط'); break;
      case 'sharezip': if (N) nat('shareApk', shareText(), true); else toast('المشاركة متاحة داخل التطبيق فقط'); break;
      case 'pick': nat('pickPhoto'); break;
      case 'savecfg':
        var links = [];
        for (var q = 0; q < 3; q++) { var u = $('a_u' + q).value.trim(); if (u) { if (!/^https:\/\//.test(u)) { toast('الرابط ' + ar(q + 1) + ' يجب أن يبدأ بـ https://'); return; } links.push({ title: $('a_t' + q).value.trim(), url: u }); } }
        store('cfg_audio', JSON.stringify(links));
        store('cfg_title', $('f_title').value); store('cfg_name', $('f_name').value); store('cfg_dua', $('f_dua').value);
        toast('تم الحفظ'); window.appBack(); break;
      case 'resetcfg':
        if (!el.getAttribute('data-sure')) { el.setAttribute('data-sure', '1'); el.lastChild.textContent = 'اضغط مرة أخرى للتأكيد'; break; }
        ['title', 'name', 'dua', 'audio'].forEach(function (k) { try { localStorage.removeItem('cfg_' + k); } catch (e) { } });
        nat('resetPhoto'); toast('تم الاسترجاع'); window.appBack(); break;
      case 'go': go({ v: el.getAttribute('data-v'), k: el.getAttribute('data-k') }); break;
      case 'surah': var i = +el.getAttribute('data-i'); go({ v: 'pages', i: i, p: START[i] }); break;
      case 'reader':
        var old = reader; reader = el.getAttribute('data-id'); store('reader', reader);
        [].forEach.call(document.querySelectorAll('.chip'), function (c) { c.className = 'chip' + (c.getAttribute('data-id') === reader ? ' on' : ''); });
        var dc = $('dl'); if (dc && s.v === 'juz') dc.innerHTML = dlHtml();
        var lp = (audio.listId || '').split(':');
        if (audio.mode !== 'idle' && lp[0] === 's' && lp[1] === old) nat('playSurah', reader, +lp[2], Math.max(audio.ayah, 0));
        break;
      case 'playall': playSurah(s.i, 0); break;
      case 'dua':
        var d = duaItems[+el.getAttribute('data-i')];
        if (audio.listId === 'm:' + d.id && audio.mode !== 'idle') nat('toggle'); else nat('playMedia', d.id, d.title, d.src);
        break;
      case 'toggle': nat('toggle'); break;
      case 'aprev': nat('prev'); break;
      case 'anext': nat('next'); break;
      case 'astop': nat('stop'); break;
      case 'pnext': turn(1); break;
      case 'pprev': turn(-1); break;
      case 'retry': showPage(); break;
      case 'night': night = !night; store('night', night ? '1' : '0'); var w = $('pw'); if (w) w.className = 'pgwrap' + (night ? ' night' : ''); break;
      case 'dlstart': dlS = { state: 'run', done: nat('cachedCount', reader) || 0, total: 565 }; nat('downloadJuz', reader); var dd = $('dl'); if (dd) dd.innerHTML = dlHtml(); break;
      case 'dlcancel': nat('cancelDownload'); break;
      case 'clear': nat('clearCache'); toast('تم مسح التلاوات المحفوظة'); break;
    }
  });

  // السحب بين الصفحات: من اليسار لليمين = الصفحة التالية (كالمصحف الورقي)
  var tx = null, ty = null;
  document.addEventListener('touchstart', function (e) { var t = e.touches[0]; tx = t.clientX; ty = t.clientY; }, { passive: true });
  document.addEventListener('touchend', function (e) {
    if (tx === null || cur().v !== 'pages') { tx = null; return; }
    var t = e.changedTouches[0], dx = t.clientX - tx, dy = t.clientY - ty; tx = null;
    if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.8) turn(dx > 0 ? 1 : -1);
  }, { passive: true });

  render();
  window.onResumeApp();
})();
