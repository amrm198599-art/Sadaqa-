package com.sadaqa.jariya;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * مشغّل صوتي: تلاوة آية بآية مع تخزين مؤقت على الجهاز.
 *  - أول تشغيل: تحميل ملف الآية ثم حفظه في cache/audio.
 *  - بعدها: يعمل دون إنترنت من الملف المحفوظ.
 *  - أثناء تشغيل آية يُحمَّل مسبقًا الآيتان التاليتان لتشغيل متصل دون انقطاع.
 * كل دوال التحكم تُستدعى من الخيط الرئيسي.
 */
final class AudioBridge {

    interface Emitter { void emit(String json); }

    /** مصدر التلاوات: everyayah.com (ملف لكل آية: SSSAAA.mp3). غيّر المجلد هنا إن لزم. */
    private static final String BASE = "https://everyayah.com/data/";
    private static final String F_ABDULBASIT = "Abdul_Basit_Mujawwad_128kbps";
    private static final String F_AJAMI = "Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net";
    private static final String F_MINSHAWI = "Minshawy_Mujawwad_192kbps";

    /** عدد آيات السور 78..114 */
    private static final int[] COUNTS = {40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26, 30, 20, 15, 21, 11,
            8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6};

    private static final long MAX_CACHE = 450L * 1024 * 1024;

    private static final class Track {
        final int ayah;        // 0 = البسملة، -1 = ملف مفرد (دعاء)
        final String url;      // رابط (أو null إن كان من assets)
        final String asset;    // مسار داخل assets (أو null)
        final String rel;      // اسم الملف داخل مجلد الكاش
        Track(int ayah, String url, String asset, String rel) {
            this.ayah = ayah; this.url = url; this.asset = asset; this.rel = rel;
        }
    }

    private final Context ctx;
    private final Emitter emitter;
    private final Emitter progress;
    private final ExecutorService dlExec = Executors.newSingleThreadExecutor();
    private volatile boolean dlRunning = false, dlCancel = false;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final ConcurrentHashMap<String, Object> locks = new ConcurrentHashMap<>();
    private final AudioManager am;

    private MediaPlayer mp;
    private final List<Track> list = new ArrayList<>();
    private int idx = -1;
    private int gen = 0;
    private String mode = "idle";   // idle | loading | playing | paused
    private String listId = "";
    private AudioFocusRequest focusReq;

    private final AudioManager.OnAudioFocusChangeListener focusListener = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (mp != null && "playing".equals(mode)) {
                try { mp.pause(); } catch (Exception ignored) { }
                mode = "paused";
                emit(null);
            }
        }
    };

    AudioBridge(Context c, Emitter e, Emitter prog) {
        ctx = c.getApplicationContext();
        emitter = e;
        progress = prog;
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
    }

    // ------------------------- واجهة التحكم -------------------------

    void playSurah(String reader, int surah, int startAyah) {
        String folder = folderOf(reader);
        if (folder == null || surah < 78 || surah > 114) { fail("قارئ أو سورة غير معروفة"); return; }
        list.clear();
        list.add(new Track(0, url(folder, 1, 1), null, folder + "/001001.mp3"));   // البسملة
        int n = COUNTS[surah - 78];
        for (int a = 1; a <= n; a++) {
            String name = String.format(java.util.Locale.US, "%03d%03d.mp3", surah, a);
            list.add(new Track(a, BASE + folder + "/" + name, null, folder + "/" + name));
        }
        listId = "s:" + reader + ":" + surah;
        start(startAyah <= 0 ? 0 : Math.min(startAyah, n));
    }

    /** src: رابط https أو "asset:مسار/داخل/assets" */
    void playMedia(String id, String title, String src) {
        if (src == null) { fail("مصدر الصوت غير محدد"); return; }
        list.clear();
        if (src.startsWith("asset:")) {
            list.add(new Track(-1, null, src.substring(6), null));
        } else if (src.startsWith("https://")) {
            list.add(new Track(-1, src, null, "media/" + Integer.toHexString(src.hashCode()) + ".mp3"));
        } else { fail("مصدر الصوت غير مدعوم"); return; }
        listId = "m:" + id;
        start(0);
    }

    void toggle() {
        if (mp == null) return;
        try {
            if ("playing".equals(mode)) {
                mp.pause(); mode = "paused"; emit(null);
            } else if ("paused".equals(mode)) {
                if (requestFocus()) { mp.start(); mode = "playing"; emit(null); }
            }
        } catch (Exception e) { fail("تعذّر التحكم بالتشغيل"); }
    }

    void next(boolean auto) {
        if (list.isEmpty()) return;
        if (idx + 1 < list.size()) start(idx + 1);
        else if (auto) { stop(); }
    }

    void prev() {
        if (list.isEmpty()) return;
        start(Math.max(0, idx - 1));
    }

    void stop() {
        gen++;
        releasePlayer();
        abandonFocus();
        list.clear();
        idx = -1;
        mode = "idle";
        listId = "";
        emit(null);
    }

    void release() {
        dlCancel = true;
        dlExec.shutdownNow();
        gen++;
        releasePlayer();
        abandonFocus();
        io.shutdownNow();
    }

    // ----------------------------- التشغيل -----------------------------

    private void start(int i) {
        if (i < 0 || i >= list.size()) { stop(); return; }
        gen++;
        final int g = gen;
        releasePlayer();
        idx = i;
        mode = "loading";
        emit(null);

        final Track t = list.get(i);
        if (t.asset != null) { prepare(t, null, g); return; }

        final File f = cacheFile(t);
        if (f.exists() && f.length() > 0) {
            //noinspection ResultOfMethodCallIgnored
            f.setLastModified(System.currentTimeMillis());
            prepare(t, f, g);
        } else {
            io.execute(() -> {
                final boolean ok = download(t);
                main.post(() -> {
                    if (g != gen) return;
                    if (ok) prepare(t, cacheFile(t), g);
                    else fail("تعذّر تحميل التلاوة. تحقق من اتصال الإنترنت ثم أعد المحاولة");
                });
            });
        }
    }

    private void prepare(final Track t, final File f, final int g) {
        try {
            MediaPlayer m = new MediaPlayer();
            mp = m;
            m.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK);
            if (t.asset != null) {
                AssetFileDescriptor afd = ctx.getAssets().openFd(t.asset);
                try { m.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength()); }
                finally { afd.close(); }
            } else {
                m.setDataSource(f.getAbsolutePath());
            }
            m.setOnPreparedListener(p -> {
                if (g != gen) { p.release(); return; }
                if (requestFocus()) {
                    p.start();
                    mode = "playing";
                    prefetch(idx + 1);
                    prefetch(idx + 2);
                } else {
                    mode = "paused";
                }
                emit(null);
            });
            m.setOnCompletionListener(p -> { if (g == gen) next(true); });
            m.setOnErrorListener((p, what, extra) -> {
                if (g == gen) {
                    if (f != null) { //noinspection ResultOfMethodCallIgnored
                        f.delete(); }   // ملف تالف: يُعاد تحميله لاحقًا
                    fail("تعذّر تشغيل هذا الملف الصوتي");
                }
                return true;
            });
            m.prepareAsync();
        } catch (java.io.FileNotFoundException e) {
            fail("ملف الصوت غير موجود داخل التطبيق");
        } catch (Exception e) {
            fail("تعذّر تشغيل الصوت");
        }
    }

    private void prefetch(int i) {
        if (i < 0 || i >= list.size()) return;
        final Track t = list.get(i);
        if (t.url == null) return;
        final File f = cacheFile(t);
        if (f.exists() && f.length() > 0) return;
        io.execute(() -> download(t));
    }

    private boolean download(Track t) {
        File f = cacheFile(t);
        Object lock = new Object();
        Object prev = locks.putIfAbsent(f.getName() + t.rel, lock);
        if (prev != null) lock = prev;
        synchronized (lock) {
            if (f.exists() && f.length() > 0) return true;
            File dir = f.getParentFile();
            if (dir != null && !dir.exists() && !dir.mkdirs()) return false;
            File tmp = new File(f.getPath() + ".tmp");
            HttpURLConnection c = null;
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    c = (HttpURLConnection) new URL(t.url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    c.setRequestProperty("User-Agent", "SadaqaJariya/1.0");
                    if (c.getResponseCode() != 200) continue;
                    try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    }
                    if (tmp.length() > 0 && tmp.renameTo(f)) { trim(); return true; }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.disconnect();
                    if (tmp.exists() && !f.exists()) //noinspection ResultOfMethodCallIgnored
                        tmp.delete();
                }
            }
            return false;
        }
    }

    // ------------------- تحميل جزء عمّ كاملاً لقارئ (مرة واحدة) -------------------

    void downloadJuz(final String reader) {
        final String folder = folderOf(reader);
        if (folder == null || dlRunning) return;
        dlRunning = true;
        dlCancel = false;
        dlExec.execute(() -> {
            List<Track> all = new ArrayList<>();
            all.add(new Track(0, url(folder, 1, 1), null, folder + "/001001.mp3"));
            for (int i = 0; i < COUNTS.length; i++) {
                for (int a = 1; a <= COUNTS[i]; a++) {
                    String name = String.format(java.util.Locale.US, "%03d%03d.mp3", 78 + i, a);
                    all.add(new Track(a, BASE + folder + "/" + name, null, folder + "/" + name));
                }
            }
            int done = 0;
            String state = "done";
            try {
                for (Track t : all) {
                    if (dlCancel) { state = "cancel"; break; }
                    if (!download(t)) { state = "fail"; break; }
                    done++;
                    if (done % 5 == 0 && done < all.size()) sendProgress("run", done, all.size());
                }
            } finally {
                dlRunning = false;
            }
            sendProgress(state, done, all.size());
        });
    }

    void cancelDownload() { dlCancel = true; }

    /** عدد ملفات هذا القارئ المحفوظة (من أصل 565 لجزء عمّ). */
    int cachedCount(String reader) {
        String folder = folderOf(reader);
        if (folder == null) return 0;
        File[] fs = new File(audioDir(), folder).listFiles();
        if (fs == null) return 0;
        int n = 0;
        for (File f : fs) {
            String nm = f.getName();
            if (nm.endsWith(".mp3") && f.length() > 0 && nm.compareTo("078001.mp3") >= 0) n++;
            else if (nm.equals("001001.mp3") && f.length() > 0) n++;
        }
        return n;
    }

    private void sendProgress(String state, int done, int total) {
        try {
            JSONObject o = new JSONObject();
            o.put("state", state); o.put("done", done); o.put("total", total);
            progress.emit(o.toString());
        } catch (Exception ignored) { }
    }

    // ----------------------------- الكاش -----------------------------

    private File audioDir() { return new File(ctx.getFilesDir(), "audio"); }   // دائم: لا يمسحه النظام

    private File cacheFile(Track t) { return new File(audioDir(), t.rel); }

    long cacheBytes() { return sizeOf(audioDir()); }

    void clearCache() { deleteTree(audioDir()); }

    private void trim() {
        List<File> files = new ArrayList<>();
        collect(audioDir(), files);
        List<File> keep = new ArrayList<>();
        for (File f : files) { File pd = f.getParentFile(); if (pd != null && "media".equals(pd.getName())) keep.add(f); }
        files.removeAll(keep);   // الأدعية المحمّلة لا تُحذف تلقائيًا
        long total = 0;
        for (File f : files) total += f.length();
        if (total <= MAX_CACHE) return;
        File[] arr = files.toArray(new File[0]);
        Arrays.sort(arr, Comparator.comparingLong(File::lastModified));
        for (File f : arr) {
            if (total <= MAX_CACHE * 0.8) break;
            long len = f.length();
            if (f.delete()) total -= len;
        }
    }

    private static void collect(File d, List<File> out) {
        File[] fs = d.listFiles();
        if (fs == null) return;
        for (File f : fs) { if (f.isDirectory()) collect(f, out); else out.add(f); }
    }

    private static long sizeOf(File d) {
        List<File> fs = new ArrayList<>();
        collect(d, fs);
        long t = 0;
        for (File f : fs) t += f.length();
        return t;
    }

    private static void deleteTree(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) { if (f.isDirectory()) deleteTree(f); else //noinspection ResultOfMethodCallIgnored
            f.delete(); }
        //noinspection ResultOfMethodCallIgnored
        d.delete();
    }

    // ----------------------------- مساعدات -----------------------------

    private static String folderOf(String reader) {
        if ("abdulbasit".equals(reader)) return F_ABDULBASIT;
        if ("ajami".equals(reader)) return F_AJAMI;
        if ("minshawi".equals(reader)) return F_MINSHAWI;
        return null;
    }

    private static String url(String folder, int s, int a) {
        return BASE + folder + "/" + String.format(java.util.Locale.US, "%03d%03d.mp3", s, a);
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.setOnPreparedListener(null); mp.setOnCompletionListener(null); mp.setOnErrorListener(null); } catch (Exception ignored) { }
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
    }

    private boolean requestFocus() {
        if (am == null) return true;
        int r;
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusReq == null) {
                focusReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setOnAudioFocusChangeListener(focusListener).build();
            }
            r = am.requestAudioFocus(focusReq);
        } else {
            //noinspection deprecation
            r = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        return r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    private void abandonFocus() {
        if (am == null) return;
        if (Build.VERSION.SDK_INT >= 26) { if (focusReq != null) am.abandonAudioFocusRequest(focusReq); }
        else //noinspection deprecation
            am.abandonAudioFocus(focusListener);
    }

    private void fail(String msg) {
        gen++;
        releasePlayer();
        mode = "paused".equals(mode) ? "paused" : "idle";
        mode = "idle";
        list.clear();
        idx = -1;
        listId = "";
        emit(msg);
    }

    private void emit(String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("mode", mode);
            o.put("listId", listId);
            o.put("ayah", (idx >= 0 && idx < list.size()) ? list.get(idx).ayah : -1);
            o.put("msg", msg == null ? "" : msg);
            emitter.emit(o.toString());
        } catch (Exception ignored) { }
    }
}
