package com.sadaqa.jariya;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/index.html";

    private WebView web;
    private AudioBridge audio;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private volatile boolean sharing = false;
    private volatile String lastState = "";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            web = new WebView(this);
        } catch (Throwable t) {
            // بعض الهواتف القديمة قد يكون WebView فيها معطلاً
            Toast.makeText(this, "مكوّن WebView غير متاح. حدّثه من متجر جوجل بلاي.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        web.setBackgroundColor(0xFF0A1424);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);          // لقراءة ملفات assets فقط
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);                  // لا يتأثر التصميم بحجم خط النظام
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        audio = new AudioBridge(this, json -> {
            lastState = json;
            eval("window.onAudio&&window.onAudio(" + json + ")");
        }, json -> eval("window.onDl&&window.onDl(" + json + ")"));

        web.addJavascriptInterface(new JsBridge(), "Native");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }

            // يمنع الإغلاق المفاجئ إذا انهارت عملية WebView (نقص الذاكرة مثلاً)
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                main.post(MainActivity.this::recreate);
                return true;
            }
        });

        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        web.loadUrl(HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        eval("window.onResumeApp&&window.onResumeApp()");
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.appBack?window.appBack():false", v -> {
            if (!"true".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        if (audio != null) audio.release();
        io.shutdownNow();
        if (web != null) {
            web.removeJavascriptInterface("Native");
            web.stopLoading();
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void eval(String js) {
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void toast(String m) {
        main.post(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    // ------------------------------------------------------------------
    //  مشاركة ملف الـ APK الفعلي (مباشرة، أو مضغوطًا ZIP للتطبيقات التي ترفض .apk)
    // ------------------------------------------------------------------
    private void shareApk(String text, boolean asZip) {
        if (sharing) return;
        sharing = true;
        final String msg = (text == null || text.trim().isEmpty()) ? getString(R.string.share_text)
                : (text.length() > 600 ? text.substring(0, 600) : text);
        io.execute(() -> {
            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdirs failed");
                File[] old = dir.listFiles();
                if (old != null) {
                    for (File f : old) { if (!f.delete()) f.deleteOnExit(); }
                }
                File src = new File(getApplicationInfo().sourceDir);   // base.apk المثبّت
                File out;
                if (asZip) {
                    out = new File(dir, "Sadaqa-Jariya.zip");
                    try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(out));
                         InputStream in = new FileInputStream(src)) {
                        z.putNextEntry(new ZipEntry("Sadaqa-Jariya.apk"));
                        copy(in, z);
                        z.closeEntry();
                    }
                } else {
                    out = new File(dir, "Sadaqa-Jariya.apk");
                    try (InputStream in = new FileInputStream(src); OutputStream o = new FileOutputStream(out)) {
                        copy(in, o);
                    }
                }
                if (out.length() == 0) throw new IOException("empty file");
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
                final String mime = asZip ? "application/zip" : "application/vnd.android.package-archive";
                final String body = asZip ? msg + "\n\n(الملف مضغوط: فك الضغط ثم ثبّت ملف Sadaqa-Jariya.apk)" : msg;
                main.post(() -> launchShare(uri, mime, body));
            } catch (Throwable t) {
                toast("تعذّر تجهيز ملف التطبيق للمشاركة");
            } finally {
                sharing = false;
            }
        });
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
    }

    private void launchShare(Uri uri, String mime, String text) {
        if (isFinishing()) return;
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            send.putExtra(Intent.EXTRA_TEXT, text);
            send.setClipData(ClipData.newRawUri("apk", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, getString(R.string.share_chooser));
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(chooser);
        } catch (ActivityNotFoundException e) {
            toast("لا يوجد تطبيق يدعم المشاركة");
        } catch (Throwable t) {
            toast("تعذّرت المشاركة");
        }
    }

    // ------------------------------------------------------------------
    //  تغيير صورة المرحوم من داخل التطبيق
    // ------------------------------------------------------------------
    private static final int REQ_PHOTO = 41;

    private File photoFile() { return new File(getFilesDir(), "profile.jpg"); }

    private void pickPhoto() {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "اختر الصورة"), REQ_PHOTO);
        } catch (Throwable t) {
            toast("تعذّر فتح معرض الصور");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PHOTO || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        io.execute(() -> {
            boolean ok = savePhoto(uri);
            if (!ok) toast("تعذّر استخدام هذه الصورة");
            eval("window.onPhoto&&window.onPhoto(" + ok + ")");
        });
    }

    /** ينسخ الصورة، يصغّرها (حتى 1200px)، يصحّح الدوران، ويحفظها JPEG داخل التطبيق. */
    private boolean savePhoto(Uri uri) {
        File tmp = new File(getCacheDir(), "pick.tmp");
        Bitmap bmp = null, rot = null;
        try {
            try (InputStream in = getContentResolver().openInputStream(uri); OutputStream o = new FileOutputStream(tmp)) {
                if (in == null) return false;
                copy(in, o);
            }
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(tmp.getAbsolutePath(), o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return false;
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 1200) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            bmp = BitmapFactory.decodeFile(tmp.getAbsolutePath(), o);
            if (bmp == null) return false;

            int deg = 0;
            try {
                int ori = new ExifInterface(tmp.getAbsolutePath())
                        .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (ori == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
                else if (ori == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            } catch (Throwable ignored) { }
            Bitmap use = bmp;
            if (deg != 0) {
                Matrix m = new Matrix();
                m.postRotate(deg);
                rot = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                use = rot;
            }
            File out = photoFile(), part = new File(getFilesDir(), "profile.part");
            try (FileOutputStream fo = new FileOutputStream(part)) {
                if (!use.compress(Bitmap.CompressFormat.JPEG, 88, fo)) return false;
            }
            if (out.exists() && !out.delete()) return false;
            return part.renameTo(out);
        } catch (Throwable t) {
            return false;
        } finally {
            if (bmp != null) bmp.recycle();
            if (rot != null) rot.recycle();
            if (tmp.exists() && !tmp.delete()) tmp.deleteOnExit();
        }
    }

    // ------------------------------------------------------------------
    //  الجسر بين JavaScript وجافا (كل الدوال تُنفَّذ على الخيط الرئيسي)
    // ------------------------------------------------------------------
    private class JsBridge {
        @JavascriptInterface public void shareApk(String text, boolean asZip) { MainActivity.this.shareApk(text, asZip); }

        @JavascriptInterface public void pickPhoto() { main.post(MainActivity.this::pickPhoto); }
        @JavascriptInterface public String photoUrl() {
            File f = photoFile();
            return (f.exists() && f.length() > 0) ? "file://" + f.getAbsolutePath() + "?v=" + f.lastModified() : "";
        }
        @JavascriptInterface public void resetPhoto() {
            File f = photoFile();
            if (f.exists() && !f.delete()) f.deleteOnExit();
        }

        @JavascriptInterface public void playSurah(String reader, int surah, int ayah) {
            main.post(() -> audio.playSurah(reader, surah, ayah));
        }
        @JavascriptInterface public void playMedia(String id, String title, String src) {
            main.post(() -> audio.playMedia(id, title, src));
        }
        @JavascriptInterface public void toggle() { main.post(() -> audio.toggle()); }
        @JavascriptInterface public void next()   { main.post(() -> audio.next(false)); }
        @JavascriptInterface public void prev()   { main.post(() -> audio.prev()); }
        @JavascriptInterface public void stop()   { main.post(() -> audio.stop()); }

        @JavascriptInterface public String state() { return lastState; }

        @JavascriptInterface public boolean hasAsset(String path) {
            if (path == null || path.contains("..")) return false;
            try { getAssets().open(path).close(); return true; } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void downloadJuz(String reader) { audio.downloadJuz(reader); }
        @JavascriptInterface public void cancelDownload() { audio.cancelDownload(); }
        @JavascriptInterface public int cachedCount(String reader) { return audio.cachedCount(reader); }

        @JavascriptInterface public String cacheInfo() {
            return String.valueOf(audio.cacheBytes() / (1024 * 1024));   // ميجابايت
        }
        @JavascriptInterface public void clearCache() {
            io.execute(() -> { audio.clearCache(); eval("window.onCache&&window.onCache()"); });
        }

        // صور صفحات المصحف
        @JavascriptInterface public String pageUrl(int page) { return PageStore.localUrl(MainActivity.this, page); }
        @JavascriptInterface public void fetchPage(int page) {
            io.execute(() -> {
                boolean ok = PageStore.download(MainActivity.this, page);
                eval("window.onPage&&window.onPage(" + page + "," + ok + ")");
            });
        }
    }
}
