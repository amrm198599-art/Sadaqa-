package com.sadaqa.jariya;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * صور صفحات المصحف (جزء عمّ = الصفحات 582 إلى 604).
 * الأولوية: 1) صور مضمّنة داخل التطبيق assets/pages/p582.png ...
 *           2) صور محفوظة سابقًا على الجهاز
 *           3) تنزيل الصفحة مرة واحدة من الإنترنت ثم حفظها لتعمل دون إنترنت.
 */
final class PageStore {
    /** مصادر الصور بالترتيب؛ يُجرَّب التالي إن فشل السابق. %03d = رقم الصفحة. */
    static final String[] SOURCES = {
            "https://android.quran.com/data/width_1024/page%03d.png",
            "https://quran.ksu.edu.sa/png_big/%03d.png"
    };

    private PageStore() { }

    private static File dir(Context c) { return new File(c.getFilesDir(), "pages"); }

    private static String name(int page) { return String.format(java.util.Locale.US, "p%03d.png", page); }

    /** يرجع رابط الصورة المحلي أو "" إن لم تتوفر بعد. */
    static String localUrl(Context c, int page) {
        if (page < 1 || page > 604) return "";
        try { c.getAssets().open("pages/" + name(page)).close(); return "file:///android_asset/pages/" + name(page); }
        catch (Exception ignored) { }
        File f = new File(dir(c), name(page));
        return (f.exists() && f.length() > 0) ? "file://" + f.getAbsolutePath() : "";
    }

    static boolean download(Context c, int page) {
        if (page < 1 || page > 604) return false;
        File d = dir(c);
        if (!d.exists() && !d.mkdirs()) return false;
        File out = new File(d, name(page));
        File tmp = new File(d, name(page) + ".tmp");
        for (String pattern : SOURCES) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(String.format(java.util.Locale.US, pattern, page)).openConnection();
                con.setConnectTimeout(15000);
                con.setReadTimeout(30000);
                con.setRequestProperty("User-Agent", "SadaqaJariya/1.0");
                if (con.getResponseCode() != 200) continue;
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = con.getInputStream()) {
                    byte[] b = new byte[16384];
                    int n;
                    while ((n = in.read(b)) != -1) bo.write(b, 0, n);
                }
                byte[] data = bo.toByteArray();
                // نتأكد أنه ملف PNG حقيقي وليس صفحة خطأ
                if (data.length < 2000 || (data[0] & 0xFF) != 0x89 || data[1] != 'P') continue;
                try (FileOutputStream fo = new FileOutputStream(tmp)) { fo.write(data); }
                if (tmp.renameTo(out)) return true;
            } catch (Exception ignored) {
            } finally {
                if (con != null) con.disconnect();
                if (tmp.exists()) //noinspection ResultOfMethodCallIgnored
                    tmp.delete();
            }
        }
        return false;
    }
}
