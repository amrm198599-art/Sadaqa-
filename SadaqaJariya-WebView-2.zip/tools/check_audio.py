#!/usr/bin/env python3
"""يتحقق أن روابط التلاوات الثلاثة تعمل (آية الفاتحة 1:1 وأول آية من النبأ)."""
import urllib.request
BASE = "https://everyayah.com/data/"
READERS = {
    "عبد الباسط (مجوّد)": "Abdul_Basit_Mujawwad_128kbps",
    "أحمد العجمي": "Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net",
    "المنشاوي (مجوّد)": "Minshawy_Mujawwad_192kbps",
}
for name, folder in READERS.items():
    for f in ("001001.mp3", "078001.mp3", "114006.mp3"):
        url = BASE + folder + "/" + f
        try:
            r = urllib.request.urlopen(urllib.request.Request(url, method="HEAD", headers={"User-Agent": "SadaqaJariya/1.0"}), timeout=20)
            print("OK  ", r.status, name, f)
        except Exception as e:
            print("FAIL", name, f, e)
