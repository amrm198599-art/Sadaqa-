#!/usr/bin/env python3
"""ينزّل صور صفحات جزء عمّ (582 → 604) ويضعها داخل التطبيق ليعمل دون إنترنت من أول تشغيل.
الاستخدام:  python3 tools/fetch_pages.py
غيّر SOURCES إن تغيّر المصدر (يُجرَّب بالترتيب)."""
import os, sys, urllib.request

SOURCES = [
    "https://android.quran.com/data/width_1024/page%03d.png",
    "https://quran.ksu.edu.sa/png_big/%03d.png",
]
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "pages")
os.makedirs(OUT, exist_ok=True)

def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "SadaqaJariya/1.0"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return r.read()

failed = []
for p in range(582, 605):
    dst = os.path.join(OUT, "p%03d.png" % p)
    if os.path.exists(dst) and os.path.getsize(dst) > 2000:
        continue
    for src in SOURCES:
        try:
            data = get(src % p)
            if data[:4] == b"\x89PNG" and len(data) > 2000:
                open(dst, "wb").write(data)
                print("OK  ", p, src.split("/")[2], len(data) // 1024, "KB")
                break
        except Exception as e:
            print("fail", p, src.split("/")[2], e)
    else:
        failed.append(p)

if failed:
    print("لم تُنزَّل الصفحات:", failed); sys.exit(1)
print("تم: 23 صفحة داخل", os.path.normpath(OUT))
