package com.sadaqa.jariya;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/index.html";

    private WebView web;
    private AudioBridge audio;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private volatile boolean sharing = false;
    private volatile String lastState = "";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            web = new WebView(this);
        } catch (Throwable t) {
            // بعض الهواتف القديمة قد يكون WebView فيها معطلاً
            Toast.makeText(this, "مكوّن WebView غير متاح. حدّثه من متجر جوجل بلاي.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        web.setBackgroundColor(0xFF0A1424);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);          // لقراءة ملفات assets فقط
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);                  // لا يتأثر التصميم بحجم خط النظام
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        audio = new AudioBridge(this, json -> {
            lastState = json;
            eval("window.onAudio&&window.onAudio(" + json + ")");
        });

        web.addJavascriptInterface(new JsBridge(), "Native");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }

            // يمنع الإغلاق المفاجئ إذا انهارت عملية WebView (نقص الذاكرة مثلاً)
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                main.post(MainActivity.this::recreate);
                return true;
            }
        });

        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        web.loadUrl(HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        eval("window.onResumeApp&&window.onResumeApp()");
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        web.evaluateJavascript("window.appBack?window.appBack():false", v -> {
            if (!"true".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        if (audio != null) audio.release();
        io.shutdownNow();
        if (web != null) {
            web.removeJavascriptInterface("Native");
            web.stopLoading();
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private void eval(String js) {
        main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private void toast(String m) {
        main.post(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    // ------------------------------------------------------------------
    //  مشاركة ملف الـ APK الفعلي
    // ------------------------------------------------------------------
    private void shareApk() {
        if (sharing) return;
        sharing = true;
        io.execute(() -> {
            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdirs failed");
                File[] old = dir.listFiles();
                if (old != null) {
                    for (File f : old) { if (!f.delete()) f.deleteOnExit(); }
                }

                File out = new File(dir, "Sadaqa-Jariya.apk");
                File src = new File(getApplicationInfo().sourceDir);   // base.apk المثبّت
                try (InputStream in = new FileInputStream(src);
                     OutputStream o = new FileOutputStream(out)) {
                    byte[] buf = new byte[32768];
                    int n;
                    while ((n = in.read(buf)) != -1) o.write(buf, 0, n);
                }
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
                main.post(() -> launchShare(uri));
            } catch (Throwable t) {
                toast("تعذّر تجهيز ملف التطبيق للمشاركة");
            } finally {
                sharing = false;
            }
        });
    }

    private void launchShare(Uri uri) {
        if (isFinishing()) return;
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/vnd.android.package-archive");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
            send.putExtra(Intent.EXTRA_TEXT, getString(R.string.share_text));
            send.setClipData(ClipData.newRawUri("apk", uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, getString(R.string.share_chooser)));
        } catch (ActivityNotFoundException e) {
            toast("لا يوجد تطبيق يدعم المشاركة");
        } catch (Throwable t) {
            toast("تعذّرت المشاركة");
        }
    }

    // ------------------------------------------------------------------
    //  الجسر بين JavaScript وجافا (كل الدوال تُنفَّذ على الخيط الرئيسي)
    // ------------------------------------------------------------------
    private class JsBridge {
        @JavascriptInterface public void shareApk() { MainActivity.this.shareApk(); }

        @JavascriptInterface public void playSurah(String reader, int surah, int ayah) {
            main.post(() -> audio.playSurah(reader, surah, ayah));
        }
        @JavascriptInterface public void playMedia(String id, String title, String src) {
            main.post(() -> audio.playMedia(id, title, src));
        }
        @JavascriptInterface public void toggle() { main.post(() -> audio.toggle()); }
        @JavascriptInterface public void next()   { main.post(() -> audio.next(false)); }
        @JavascriptInterface public void prev()   { main.post(() -> audio.prev()); }
        @JavascriptInterface public void stop()   { main.post(() -> audio.stop()); }

        @JavascriptInterface public String state() { return lastState; }

        @JavascriptInterface public boolean hasAsset(String path) {
            if (path == null || path.contains("..")) return false;
            try { getAssets().open(path).close(); return true; } catch (Exception e) { return false; }
        }

        @JavascriptInterface public String cacheInfo() {
            return String.valueOf(audio.cacheBytes() / (1024 * 1024));   // ميجابايت
        }
        @JavascriptInterface public void clearCache() {
            io.execute(() -> { audio.clearCache(); eval("window.onCache&&window.onCache()"); });
        }

        // صور صفحات المصحف
        @JavascriptInterface public String pageUrl(int page) { return PageStore.localUrl(MainActivity.this, page); }
        @JavascriptInterface public void fetchPage(int page) {
            io.execute(() -> {
                boolean ok = PageStore.download(MainActivity.this, page);
                eval("window.onPage&&window.onPage(" + page + "," + ok + ")");
            });
        }
    }
}
