package com.sadaqa.jariya

import android.content.Context

/**
 * القيم الافتراضية فقط. الاسم والدعاء والصورة تتغير من داخل التطبيق (زر ✏️ تعديل)،
 * ولو أردت تغيير الافتراضي قبل البناء عدّله هنا واستبدل res/drawable-nodpi/logo.png.
 */
object AppConfig {
    const val TITLE_AR = "صدقة جارية لروح المرحوم"
    const val TITLE_EN = "Sadaqah Jariyah for the soul of the late"

    // فارغ عمدًا: تظهر الجملة كاملة بدون اسم. يمكن إضافة اسم من زر ✏️ تعديل.
    const val NAME_AR = ""
    const val NAME_EN = ""

    const val DUA_AR = "اللهم اغفر له وارحمه، واجعل قبره روضة من رياض الجنة، وأنزله منزلاً مباركاً وأنت خير المنزلين"
    const val DUA_EN = "O Allah, forgive him and have mercy on him, make his grave a garden from the gardens of Paradise, and let him dwell in a blessed abode, for You are the best of those who grant abodes."

    val FACE = R.drawable.logo         // الشعار الافتراضي داخل الدائرة (يمكن استبداله بصورة من زر تعديل)

    class Reciter(val id: String, val ar: String, val en: String)

    /** القرّاء المتاحون. الـ id هو اسم الطبعة في خادم الصوت. لو قارئ لا يعمل غيّر سطره هنا. */
    val RECITERS = listOf(
        Reciter("ar.alafasy", "مشاري العفاسي", "Mishary Alafasy"),
        Reciter("ar.abdulbasitmurattal", "عبد الباسط عبد الصمد", "Abdul Basit (Murattal)"),
        Reciter("ar.husary", "محمود خليل الحصري", "Mahmoud Al-Husary"),
        Reciter("ar.minshawi", "محمد صديق المنشاوي", "Al-Minshawi"),
        Reciter("ar.abdurrahmaansudais", "عبد الرحمن السديس", "Abdurrahman As-Sudais"),
        Reciter("ar.saoodshuraym", "سعود الشريم", "Saud Ash-Shuraim"),
        Reciter("ar.mahermuaiqly", "ماهر المعيقلي", "Maher Al-Muaiqly")
    )

    /** رابط ملف صوت السورة (يتحمّل مرة واحدة ويُحفظ على الجهاز). */
    fun audioUrl(reciterId: String, n: Int) = "https://cdn.islamic.network/quran/audio-surah/128/$reciterId/$n.mp3"

    /** صور صفحات المصحف (604 صفحة، %03d = رقم الصفحة). تأكد من ترخيص الصور قبل النشر. */
    fun pageUrl(p: Int) = "https://raw.githubusercontent.com/GovarJabbar/Quran-PNG/master/%03d.png".format(p)

    fun reciterName(c: Context, id: String): String {
        val r = RECITERS.firstOrNull { it.id == id } ?: RECITERS[0]
        return if (c.isAr()) r.ar else r.en
    }

    /** السور المميّزة في أعلى القائمة بهذا الترتيب: البقرة، الكهف، الرحمن، الدخان، الواقعة، يس، الملك */
    val FEATURED = intArrayOf(2, 18, 55, 44, 56, 36, 67)

    /** رابط التطبيق على Google Play (يعمل بعد النشر). لو غيّرت applicationId غيّره هنا. */
    const val PLAY_URL = "https://play.google.com/store/apps/details?id=com.sadaqa.jariya"
    fun shareLink(c: Context) = PLAY_URL
}
