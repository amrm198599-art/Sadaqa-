package com.sadaqa.jariya

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** تعديل بيانات المتوفى من داخل التطبيق: العنوان، الاسم، الدعاء (عربي/إنجليزي) والصورة. */
class EditActivity : Activity() {
    private val REQ_PHOTO = 41
    private val fields = linkedMapOf<String, EditText>()
    private lateinit var preview: ImageView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(28)) }

        // الصورة
        preview = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; makeOval() }
        col.addView(preview, LinearLayout.LayoutParams(dp(130), dp(130)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        refreshPreview()
        val photoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        photoRow.addView(tv(t("🖼️ تغيير الصورة", "🖼️ Change photo"), 15f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 12); setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                startActivityForResult(Intent.createChooser(i, t("اختر صورة", "Choose a photo")), REQ_PHOTO)
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        photoRow.addView(tv(t("↩️ الشعار الأصلي", "↩️ Default logo"), 15f, C.NAVY, true).apply {
            background = rounded(C.GREEN, 12); setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { Prefs.resetPhoto(this@EditActivity); refreshPreview() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        col.addView(photoRow, lp(14))

        // الحقول
        field(col, "titleAr", "العنوان (عربي)", Prefs.titleAr(this), false, false)
        field(col, "titleEn", "Title (English)", Prefs.titleEn(this), false, true)
        field(col, "nameAr", "الاسم (عربي)", Prefs.nameAr(this), false, false)
        field(col, "nameEn", "Name (English)", Prefs.nameEn(this), false, true)
        field(col, "duaAr", "الدعاء (عربي)", Prefs.duaAr(this), true, false)
        field(col, "duaEn", "Supplication (English)", Prefs.duaEn(this), true, true)

        col.addView(tv(t("💾 حفظ", "💾 Save"), 19f, C.NAVY, true).apply {
            background = rounded(C.GOLD, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { save() }
        }, lp(22))
        col.addView(tv(t("↩️ استرجاع النصوص الافتراضية", "↩️ Restore default texts"), 15f, C.DARKGREEN, true).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { Prefs.resetTexts(this@EditActivity); recreate() }
        }, lp(8))

        setContentView(screen(t("✏️ تعديل بيانات المتوفى", "✏️ Edit details"), ScrollView(this).apply { addView(col) }))
    }

    private fun field(col: LinearLayout, key: String, label: String, value: String, multi: Boolean, ltr: Boolean) {
        col.addView(tv(label, 14f, C.DARKGREEN, true).apply { gravity = Gravity.START }, lp(14))
        val e = EditText(this).apply {
            setText(value); setTextColor(C.NAVY); textSize = 17f
            background = rounded(C.WHITE, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutDirection = if (ltr) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.START
            inputType = if (multi) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
            if (multi) { minLines = 3; gravity = Gravity.TOP or Gravity.START }
        }
        fields[key] = e
        col.addView(e, lp(4))
    }

    private fun save() {
        val v = HashMap<String, String>()
        for ((k, e) in fields) v[k] = e.text.toString()
        Prefs.saveTexts(this, v)
        Toast.makeText(this, t("تم الحفظ", "Saved"), Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun refreshPreview() {
        val f = Prefs.faceBitmap(this)
        if (f != null) preview.setImageBitmap(f) else preview.setImageResource(AppConfig.FACE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PHOTO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            val ok = Prefs.savePhoto(this, uri)
            runOnUiThread {
                if (ok) refreshPreview()
                else Toast.makeText(this, t("تعذّر قراءة الصورة", "Could not read the photo"), Toast.LENGTH_LONG).show()
            }
        }.start()
    }
}
