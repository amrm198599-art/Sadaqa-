package com.sadaqa.jariya

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
    }

    override fun onResume() {
        super.onResume()
        build()   // يعيد البناء لعرض أي تعديل في الاسم/الصورة/اللغة
    }

    private fun build() {
        val root = FrameLayout(this)
        val custom = Prefs.photoBitmap(this)
        if (custom != null) {
            // صورة اختارها المستخدم: خلفية معتّمة
            root.addView(ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(custom) }, ViewGroup.LayoutParams(-1, -1))
            root.addView(android.view.View(this).apply { setBackgroundColor(0xD00B1F3A.toInt()) }, ViewGroup.LayoutParams(-1, -1))
        } else {
            root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF0B1F3A.toInt(), 0xFF16456B.toInt()))
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(32))
        }

        // دائرة الصورة/الشعار: واسعة (حتى 300dp أو عرض الشاشة)
        val size = minOf(dp(300), resources.displayMetrics.widthPixels - dp(48))
        val face = Prefs.faceBitmap(this)
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            if (face != null) setImageBitmap(face) else setImageResource(AppConfig.FACE)
            makeOval()
        }
        if (face != null) {
            // صورة شخصية: إطار ذهبي. الشعار الافتراضي له إطاره الذهبي الخاص فلا نضيف إطارًا.
            val ring = FrameLayout(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.GOLD) }
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }
            ring.addView(img, FrameLayout.LayoutParams(size, size))
            col.addView(ring, LinearLayout.LayoutParams(-2, -2))
        } else {
            col.addView(img, LinearLayout.LayoutParams(size, size))
        }

        // الجملة كاملة؛ والاسم يظهر فقط لو أضافه المستخدم من زر تعديل
        val name = Prefs.name(this)
        if (name.isBlank()) {
            col.addView(tv(Prefs.title(this), 26f, C.WHITE, true), lp(20))
        } else {
            col.addView(tv(Prefs.title(this), 16f, C.GREEN), lp(18))
            col.addView(tv(name, 28f, C.WHITE, true), lp(4))
        }
        col.addView(tv(Prefs.dua(this), 17f, C.LIGHT).apply {
            background = rounded(0x33FFFFFF, 16); setPadding(dp(16), dp(14), dp(16), dp(14))
        }, lp(16))

        fun btn(label: String, bg: Int = C.LIGHT, fg: Int = C.NAVY, onClick: () -> Unit) {
            col.addView(tv(label, 18f, fg, true).apply {
                background = rounded(bg, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
                setOnClickListener { onClick() }
            }, lp(12))
        }
        fun open(k: String) = { startActivity(Intent(this, SectionActivity::class.java).putExtra("k", k)); Unit }

        val link = AppConfig.shareLink(this)
        btn(t("📤 شارك التطبيق لزيادة الأجر", "📤 Share the app to increase the reward"), C.GOLD) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Prefs.shareText(this@MainActivity) + "\n" + link)
            }, t("مشاركة التطبيق", "Share app")))
        }
        // مشاركة ملف التطبيق نفسه (متاحة فقط لو التطبيق مثبّت من APK واحد؛ تثبيت Google Play يكون مقسّمًا)
        val single = applicationInfo.splitSourceDirs.isNullOrEmpty()
        if (single) {
            btn(t("📦 أرسل ملف التطبيق (APK) بدون إنترنت", "📦 Send the app file (APK) offline"), C.GREEN) {
                val uri = android.net.Uri.parse("content://" + packageName + ".apk/SadaqaJariya.apk")
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.android.package-archive"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, t("إرسال التطبيق", "Send app")))
            }
        }
        btn(t("📖 القرآن الكريم", "📖 Holy Quran")) { startActivity(Intent(this, QuranListActivity::class.java)) }
        btn(t("🌅 أذكار الصباح والمساء", "🌅 Morning & Evening Adhkar"), onClick = open("azkar"))
        btn(t("⏰ تذكير الأذكار", "⏰ Adhkar reminders")) { startActivity(Intent(this, RemindersActivity::class.java)) }
        btn(t("🛡️ حصن المسلم", "🛡️ Fortress of the Muslim"), onClick = open("hisn"))
        btn(t("🤲 أدعية للمتوفى", "🤲 Supplications for the Deceased"), onClick = open("dua"))
        btn(t("📿 السبحة الإلكترونية", "📿 Digital Tasbih")) { startActivity(Intent(this, TasbihActivity::class.java)) }
        btn(t("📜 الأحاديث النبوية", "📜 Prophetic Hadith"), onClick = open("hadith"))

        // صف الأدوات: تعديل / اللغة / الخصوصية
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(label: String, onClick: () -> Unit) {
            tools.addView(tv(label, 14f, C.WHITE, true).apply {
                background = rounded(0x44FFFFFF, 12); setPadding(dp(6), dp(12), dp(6), dp(12))
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        small(t("✏️ تعديل", "✏️ Edit")) { startActivity(Intent(this, EditActivity::class.java)) }
        small(if (isAr()) "🌐 English" else "🌐 العربية") {
            Prefs.setLang(this, if (isAr()) "en" else "ar"); build()
        }
        small(t("🔒 الخصوصية", "🔒 Privacy")) { startActivity(Intent(this, PrivacyActivity::class.java)) }
        col.addView(tools, lp(22))

        val scroll = ScrollView(this).apply { addView(col) }
        root.addView(scroll)
        root.onInsets { l, tp, r, b -> col.setPadding(dp(20) + l, dp(40) + tp, dp(20) + r, dp(32) + b) }
        rtl(root)
        setContentView(root)
    }
}
