package com.sadaqa.jariya

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Bundle
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

/** صفحة البداية لكل سورة في مصحف المدينة (604 صفحة). */
object MushafPages {
    const val COUNT = 604
    val START = intArrayOf(
        1, 2, 50, 77, 106, 128, 151, 177, 187, 208, 221, 235, 249, 255, 262, 267, 282, 293, 305, 312,
        322, 332, 342, 350, 359, 367, 377, 385, 396, 404, 411, 415, 418, 428, 434, 440, 446, 453, 458, 467,
        477, 483, 489, 496, 499, 502, 507, 511, 515, 518, 520, 523, 526, 528, 531, 534, 537, 542, 545, 549,
        551, 553, 554, 556, 558, 560, 562, 564, 566, 568, 570, 572, 574, 575, 577, 578, 580, 582, 583, 585,
        586, 587, 587, 589, 590, 591, 591, 592, 593, 594, 595, 595, 596, 596, 597, 597, 598, 598, 599, 599,
        600, 600, 601, 601, 601, 602, 602, 602, 603, 603, 603, 604, 604, 604
    )
    fun startOf(surah: Int) = START[(surah - 1).coerceIn(0, 113)]
    /** السورة التي تبدأ عندها الصفحة أو قبلها (لعرض اسمها). */
    fun surahAt(page: Int): Int {
        var r = 1
        for (i in START.indices) if (START[i] <= page) r = i + 1
        return r
    }
}

object Net {
    fun download(url: String, out: File, minBytes: Long, cancelled: () -> Boolean = { false }): Boolean {
        val part = File(out.path + ".part")
        var conn: HttpURLConnection? = null
        try {
            out.parentFile?.mkdirs()
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
            }
            if (conn.responseCode != 200) return false
            conn.inputStream.use { ins ->
                FileOutputStream(part).use { os ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        if (cancelled()) return false
                        val r = ins.read(buf)
                        if (r < 0) break
                        os.write(buf, 0, r)
                    }
                }
            }
            if (part.length() < minBytes) return false
            if (out.exists()) out.delete()
            return part.renameTo(out)
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
            if (part.exists()) part.delete()
        }
    }
}

/** صور صفحات المصحف: تتحمّل عند الحاجة (أو دفعة واحدة) وتُحفظ على الجهاز فتعمل أوفلاين. */
object PageStore {
    private val busy = java.util.Collections.synchronizedSet(HashSet<Int>())
    private fun dir(c: Context) = File(c.filesDir, "mushaf")
    fun file(c: Context, p: Int) = File(dir(c), "%03d.png".format(p))
    fun has(c: Context, p: Int) = file(c, p).let { it.exists() && it.length() > 5_000 }
    fun count(c: Context) = (1..MushafPages.COUNT).count { has(c, it) }
    fun totalBytes(c: Context): Long = dir(c).walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun clearAll(c: Context) { dir(c).deleteRecursively() }

    fun download(c: Context, p: Int, cancelled: () -> Boolean = { false }): Boolean {
        if (has(c, p)) return true
        if (!busy.add(p)) return false      // قيد التحميل بالفعل
        try {
            return Net.download(AppConfig.pageUrl(p), file(c, p), 5_000, cancelled)
        } finally {
            busy.remove(p)
        }
    }
}

class MushafActivity : Activity() {
    private var page = 1
    private var night = false
    private lateinit var img: ImageView
    private lateinit var scroll: ScrollView
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var dlBtn: TextView
    private lateinit var nightBtn: TextView
    private lateinit var gd: GestureDetector
    @Volatile private var token = 0
    @Volatile private var bulk = false
    @Volatile private var cancelled = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        night = Prefs.night(this)
        page = intent.getIntExtra("page", Prefs.lastPage(this)).coerceIn(1, MushafPages.COUNT)

        nightBtn = tv(if (night) "☀️" else "🌙", 16f, C.NAVY, true).apply {
            background = rounded(C.GREEN, 10); setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { night = !night; Prefs.setNight(this@MushafActivity, night); text = if (night) "☀️" else "🌙"; applyNight() }
        }

        info = tv("", 16f, C.NAVY, true)
        status = tv("", 13f, C.DARKGREEN)
        img = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }
        scroll = ScrollView(this).apply { addView(img, ViewGroupLP(-1, -2)) }

        fun nav(label: String, onClick: () -> Unit) = tv(label, 16f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 12); setPadding(dp(8), dp(12), dp(8), dp(12)); setOnClickListener { onClick() }
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR }
        fun add(v: TextView) = bar.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        add(nav(t("التالي ⬅", "Next ⬅")) { go(page + 1) })
        add(nav(t("🔢 صفحة", "🔢 Page")) { askPage() })
        add(nav(t("📚 سورة", "📚 Surah")) { askSurah() })
        add(nav(t("➡ السابق", "➡ Prev")) { go(page - 1) })

        dlBtn = tv("", 14f, C.NAVY, true).apply {
            background = rounded(C.GREEN, 12); setPadding(dp(8), dp(10), dp(8), dp(10)); setOnClickListener { onBulk() }
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(4)) }
        top.addView(info); top.addView(status, lp(2))
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(top)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8)) }
        bottom.addView(bar, lp()); bottom.addView(dlBtn, lp(6))
        content.addView(bottom)

        // السحب: كتاب عربي — السحب لليمين = الصفحة التالية
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                if (abs(dx) > dp(120) && abs(dx) > abs(e2.y - e1.y) * 2) { go(if (dx > 0) page + 1 else page - 1); return true }
                return false
            }
        })

        setContentView(screen(t("📄 المصحف", "📄 Mushaf"), content, nightBtn))
        refreshDlBtn()
        applyNight()
        show()
    }

    private fun ViewGroupLP(w: Int, h: Int) = android.view.ViewGroup.LayoutParams(w, h)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onDestroy() { cancelled = true; super.onDestroy() }

    private fun applyNight() {
        scroll.setBackgroundColor(if (night) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        if (night) {
            val inv = ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f))
            img.colorFilter = ColorMatrixColorFilter(inv)
        } else img.colorFilter = null
    }

    private fun go(p: Int) {
        if (p < 1 || p > MushafPages.COUNT) return
        page = p; show()
    }

    private fun show() {
        Prefs.setLastPage(this, page)
        val sn = MushafPages.surahAt(page)
        val s = QuranRepo.load(this).firstOrNull { it.n == sn }
        val name = if (s != null) (if (isAr()) s.ar else s.en) else ""
        info.text = t("صفحة ", "Page ") + num(page) + " / " + num(MushafPages.COUNT) + (if (name.isNotEmpty()) " • $name" else "")
        val my = ++token
        if (PageStore.has(this, page)) { display(); prefetch(page + 1); return }
        status.text = t("جارٍ تحميل الصفحة…", "Loading page…")
        val p = page
        Thread {
            val ok = PageStore.download(this, p)
            runOnUiThread {
                if (my != token) return@runOnUiThread
                if (ok) { display(); prefetch(p + 1) }
                else status.text = t("تعذّر تحميل الصفحة — تأكد من الإنترنت (الصفحات المحمّلة تعمل أوفلاين)", "Could not load the page — check your connection (downloaded pages work offline)")
            }
        }.start()
    }

    private fun display() {
        status.text = ""
        val f = PageStore.file(this, page)
        val w = resources.displayMetrics.widthPixels
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        var sample = 1
        while (o.outWidth > 0 && o.outWidth / (sample * 2) >= w) sample *= 2
        val bmp: Bitmap? = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        if (bmp == null) {
            f.delete()
            status.text = t("الصورة تالفة — جرّب مرة أخرى", "Image is corrupt — try again")
        } else {
            img.setImageBitmap(bmp)
            scroll.scrollTo(0, 0)
        }
    }

    private fun prefetch(p: Int) {
        if (p > MushafPages.COUNT || PageStore.has(this, p)) return
        Thread { PageStore.download(this, p) }.start()
    }

    private fun askPage() {
        val e = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "1 – ${MushafPages.COUNT}"; setPadding(dp(20), dp(12), dp(20), dp(12)) }
        AlertDialog.Builder(this).setTitle(t("اذهب إلى صفحة", "Go to page")).setView(e)
            .setPositiveButton(t("اذهب", "Go")) { _, _ ->
                val n = e.text.toString().trim().toIntOrNull()
                if (n != null && n in 1..MushafPages.COUNT) go(n) else Toast.makeText(this, t("رقم غير صحيح", "Invalid number"), Toast.LENGTH_SHORT).show()
            }.setNegativeButton(t("إلغاء", "Cancel"), null).show()
    }

    private fun askSurah() {
        val l = QuranRepo.load(this)
        val names = l.map { num(it.n) + ". " + (if (isAr()) it.ar else it.en) }.toTypedArray()
        AlertDialog.Builder(this).setTitle(t("اختر السورة", "Choose a surah"))
            .setItems(names) { _, i -> go(MushafPages.startOf(l[i].n)) }.show()
    }

    /* ---------- تحميل المصحف كاملًا ---------- */
    private fun refreshDlBtn() {
        val have = PageStore.count(this)
        dlBtn.text = when {
            bulk -> t("⏹ إيقاف التحميل", "⏹ Stop downloading")
            have >= MushafPages.COUNT -> t("✅ المصحف كامل على الجهاز (يعمل بدون إنترنت)", "✅ Full Mushaf on device (works offline)")
            else -> t("⬇ تحميل المصحف كاملًا للاستخدام بدون إنترنت (${num(have)}/${num(MushafPages.COUNT)})", "⬇ Download the full Mushaf for offline use ($have/${MushafPages.COUNT})")
        }
    }

    private fun onBulk() {
        if (bulk) { cancelled = true; return }
        if (PageStore.count(this) >= MushafPages.COUNT) return
        AlertDialog.Builder(this)
            .setMessage(t("سيتم تحميل صفحات المصحف (قد تصل إلى مئات الميجابايت). يُفضّل استخدام Wi-Fi. متابعة؟",
                "This downloads the Mushaf pages (could be several hundred MB). Wi-Fi recommended. Continue?"))
            .setPositiveButton(t("تحميل", "Download")) { _, _ -> startBulk() }
            .setNegativeButton(t("إلغاء", "Cancel"), null).show()
    }

    private fun startBulk() {
        bulk = true; cancelled = false; refreshDlBtn()
        Thread {
            var failed = 0
            for (p in 1..MushafPages.COUNT) {
                if (cancelled) break
                if (PageStore.has(this, p)) continue
                if (!PageStore.download(this, p) { cancelled }) {
                    failed++
                    if (failed >= 5) break          // غالبًا انقطع الإنترنت
                }
                runOnUiThread { status.text = t("جارٍ التحميل… ", "Downloading… ") + num(PageStore.count(this)) + "/" + num(MushafPages.COUNT) }
            }
            runOnUiThread {
                bulk = false
                status.text = if (failed >= 5) t("توقف التحميل لانقطاع الاتصال — أعد المحاولة", "Stopped — connection problem, try again") else ""
                refreshDlBtn()
            }
        }.start()
    }
}
