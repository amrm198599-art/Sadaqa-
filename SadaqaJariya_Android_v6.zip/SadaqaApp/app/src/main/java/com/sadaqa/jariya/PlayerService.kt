package com.sadaqa.jariya

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.PowerManager

/** حالة المشغّل المشتركة (الخدمة تكتب والشاشات تقرأ). */
object Player {
    @Volatile var mp: MediaPlayer? = null
    @Volatile var key: String? = null
    @Volatile var error: String? = null
    @Volatile var sleepAt: Long = 0L      // elapsedRealtime لإيقاف التشغيل تلقائيًا (0 = بدون مؤقّت)
    fun make(rid: String, n: Int) = "$rid:$n"
    fun playing(): Boolean = try { mp?.isPlaying == true } catch (e: Exception) { false }
    fun pos(): Int = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    fun dur(): Int = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }
    fun seek(ms: Int) { try { mp?.seekTo(ms) } catch (e: Exception) { } }
}

/** تشغيل التلاوة في الخلفية بإشعار فيه إيقاف مؤقت/إيقاف، ويوقف نفسه عند الانتهاء. */
class PlayerService : Service() {
    companion object {
        const val ACT_PLAY = "com.sadaqa.jariya.PLAY"
        const val ACT_TOGGLE = "com.sadaqa.jariya.TOGGLE"
        const val ACT_STOP = "com.sadaqa.jariya.STOP"
        const val ACT_SLEEP = "com.sadaqa.jariya.SLEEP"
        private const val CH = "playback"
        private const val ID = 7
    }

    private var n = 0
    private var reciter = AppConfig.RECITERS[0].id
    private var focusReq: AudioFocusRequest? = null
    private var resumeAfterFocus = false
    private val handler = Handler(Looper.getMainLooper())
    private val sleepRun = Runnable { stopAll() }

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        val m = Player.mp
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                if (m != null && Player.playing()) m.pause()
                resumeAfterFocus = false; notifyState()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (m != null && Player.playing()) { m.pause(); resumeAfterFocus = true; notifyState() }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                if (m != null && resumeAfterFocus) { m.start(); resumeAfterFocus = false; notifyState() }
            }
            else -> { }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACT_PLAY -> play(intent.getStringExtra("r") ?: AppConfig.RECITERS[0].id, intent.getIntExtra("n", 0))
            ACT_TOGGLE -> toggle()
            ACT_STOP -> stopAll()
            ACT_SLEEP -> setSleep(intent.getIntExtra("min", 0))
            else -> if (Player.mp == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun play(rid: String, num: Int) {
        n = num; reciter = rid
        startFg(true)               // يجب خلال 5 ثوانٍ من startForegroundService
        releasePlayer()
        val f = AudioStore.file(this, num, rid)
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            m.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(f.absolutePath)
            m.prepare()
            m.isLooping = Prefs.repeat(this)
            m.setOnCompletionListener { stopAll() }
            requestFocus()
            Player.mp = m
            Player.key = Player.make(rid, num)
            Player.error = null
            m.start()
            notifyState()
        } catch (e: Exception) {
            f.delete()
            Player.error = "bad_file"
            stopAll()
        }
    }

    private fun toggle() {
        val m = Player.mp ?: return
        try {
            if (m.isPlaying) m.pause() else { requestFocus(); m.start() }
        } catch (e: Exception) { }
        notifyState()
    }

    private fun setSleep(min: Int) {
        handler.removeCallbacks(sleepRun)
        if (min > 0 && Player.mp != null) {
            Player.sleepAt = SystemClock.elapsedRealtime() + min * 60_000L
            handler.postDelayed(sleepRun, min * 60_000L)
        } else {
            Player.sleepAt = 0L
        }
    }

    private fun stopAll() {
        handler.removeCallbacks(sleepRun)
        Player.sleepAt = 0L
        releasePlayer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releasePlayer() {
        try { Player.mp?.release() } catch (e: Exception) { }
        Player.mp = null
        Player.key = null
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        focusReq = null
    }

    private fun requestFocus() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            .setOnAudioFocusChangeListener(focusListener).build()
        focusReq = req
        am.requestAudioFocus(req)
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }

    /* ---------- الإشعار ---------- */
    private fun notifyState() = startFg(Player.playing())

    private fun startFg(playing: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, t("التلاوة", "Recitation"), NotificationManager.IMPORTANCE_LOW))
        }
        val nf = buildNotification(playing)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, nf, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(ID, nf)
    }

    private fun action(act: String, label: String, icon: Int): Notification.Action {
        val pi = PendingIntent.getService(this, act.hashCode(),
            Intent(this, PlayerService::class.java).setAction(act), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun buildNotification(playing: Boolean): Notification {
        val s = QuranRepo.find(this, n)
        val title = if (s != null) (if (isAr()) s.ar else s.en) else t("القرآن الكريم", "Holy Quran")
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, SurahActivity::class.java).putExtra("n", n),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(AppConfig.reciterName(this, reciter))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(action(ACT_TOGGLE,
                if (playing) t("إيقاف مؤقت", "Pause") else t("تشغيل", "Play"),
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play))
            .addAction(action(ACT_STOP, t("إيقاف", "Stop"), android.R.drawable.ic_menu_close_clear_cancel))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1))
            .build()
    }
}
