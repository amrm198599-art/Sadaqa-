package com.sadaqa.jariya

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

class PrivacyActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(28)) }
        val body = t(POLICY_AR, POLICY_EN)
        col.addView(tv(body, 16f, C.NAVY).apply {
            gravity = Gravity.START; background = rounded(C.WHITE, 16); setPadding(dp(16), dp(16), dp(16), dp(16))
            setTextIsSelectable(true)
        })
        setContentView(screen(t("🔒 سياسة الخصوصية", "🔒 Privacy Policy"), ScrollView(this).apply { addView(col) }))
    }

    companion object {
        const val POLICY_AR = """هذا التطبيق صدقة جارية ولا يجمع أي بيانات عنك.

• لا يوجد حساب ولا تسجيل دخول.
• لا إعلانات ولا أدوات تحليل ولا تتبّع.
• الاسم والدعاء والصورة التي تدخلها تُحفظ على جهازك فقط ولا تُرسل لأي جهة.
• نص القرآن والأذكار والأحاديث مضمّنة في التطبيق وتعمل بدون إنترنت.
• الإنترنت يُستخدم فقط لتحميل ملف صوت السورة أو صور صفحات المصحف مرة واحدة عند طلبك، ثم تُحفظ على الجهاز ولا تحتاج إنترنت بعدها. عند التحميل قد يرى خادم الملفات عنوان الاتصال (IP) كأي موقع، ولا يستلم التطبيق منك أي بيانات أخرى.
• أثناء تشغيل الصوت يعرض التطبيق إشعارًا للتحكم فيه (يطلب إذن الإشعارات على أندرويد 13+ ويعمل التشغيل حتى لو رفضته).
• تذكير الأذكار (اختياري) يعمل محليًا على جهازك بإشعار يومي في الوقت الذي تختاره، ويُعاد جدولته بعد إعادة تشغيل الهاتف؛ لا يُرسل أي بيانات.
• التطبيق لا يطلب أذونات الكاميرا أو الموقع أو جهات الاتصال أو التخزين.
• عند اختيار صورة، يقرؤها التطبيق من المعرض مرة واحدة وينسخها داخل مساحته الخاصة، ويمكنك حذفها بزر «الصورة الأصلية» أو بإلغاء تثبيت التطبيق.

لحذف كل بياناتك: امسح بيانات التطبيق من إعدادات الجهاز أو ألغِ تثبيته."""

        const val POLICY_EN = """This app is an ongoing charity (Sadaqah Jariyah) and does not collect any data about you.

• No account or sign-in.
• No ads, analytics or tracking.
• The name, supplication and photo you enter are stored on your device only and are never sent anywhere.
• The Quran text, adhkar and hadith are bundled in the app and work offline.
• The internet is used only to download a surah's audio file or Mushaf page images once, when you ask for it; they are then saved on your device and need no internet afterwards. Like any website, the file server can see your connection address (IP); the app sends no other data.
• While audio plays, the app shows a notification with playback controls (it asks for notification permission on Android 13+; playback works even if you decline).
• The optional adhkar reminder runs locally on your device as a daily notification at the time you choose, and is rescheduled after a reboot; it sends no data.
• The app does not request camera, location, contacts or storage permissions.
• When you choose a photo, the app reads it once from your gallery and copies it into its private storage. You can remove it with the "Default photo" button or by uninstalling the app.

To delete all your data: clear the app's data in device settings or uninstall it."""
    }
}
