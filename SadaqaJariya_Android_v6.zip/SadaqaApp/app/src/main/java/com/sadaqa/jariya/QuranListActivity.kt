package com.sadaqa.jariya

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

class QuranListActivity : Activity() {
    private lateinit var col: LinearLayout
    private lateinit var search: EditText
    private var list: List<Surah>? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(6), dp(14), dp(24)) }
        search = EditText(this).apply {
            hint = t("🔍 ابحث باسم السورة أو رقمها", "🔍 Search by surah name or number")
            setTextColor(C.NAVY); setHintTextColor(0xFF7A8A99.toInt()); textSize = 16f
            background = rounded(C.WHITE, 12); setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
            gravity = Gravity.START
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) { populate() }
            })
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(10), dp(14), dp(4)) })
        content.addView(ScrollView(this).apply { addView(col) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(screen(t("📖 القرآن الكريم", "📖 Holy Quran"), content))
        col.addView(tv(t("جارٍ التحميل…", "Loading…"), 16f, C.DARKGREEN), lp(30))
        Thread {
            val l = QuranRepo.load(this)
            runOnUiThread { list = l; populate() }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (list != null) populate()   // لتحديث علامة 🔊 وآخر قراءة
    }

    private fun populate() {
        val l = list ?: return
        col.removeAllViews()
        val q = search.text.toString().trim()

        if (q.isNotEmpty()) {
            val qn = q.norm()
            val hits = l.filter { it.n.toString() == q || it.ar.norm().contains(qn) || it.en.lowercase().contains(q.lowercase()) }
            if (hits.isEmpty()) col.addView(tv(t("لا توجد نتائج", "No results"), 16f, C.DARKGREEN), lp(20))
            hits.forEach { col.addView(row(it, false), lp(8)) }
            return
        }

        if (!QuranRepo.isFull) {
            col.addView(tv(t("⚠️ نص المصحف الكامل غير مضمّن في هذه النسخة (شغّل tools/fetch_quran.py قبل البناء). المعروض سور قصيرة فقط.",
                "⚠️ The full Quran text is not bundled in this build (run tools/fetch_quran.py before building). Only a few short surahs are shown."),
                14f, C.NAVY).apply { background = rounded(0xFFFFE7A8.toInt(), 12); setPadding(dp(12), dp(10), dp(12), dp(10)) }, lp(4))
        }

        col.addView(tv(t("📄 المصحف بالصور (صفحات)", "📄 Mushaf pages (images)"), 17f, C.NAVY, true).apply {
            background = rounded(C.GOLD, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
            setOnClickListener { startActivity(Intent(this@QuranListActivity, MushafActivity::class.java)) }
        }, lp(8))

        // متابعة القراءة
        val last = l.firstOrNull { it.n == Prefs.lastSurah(this) }
        if (last != null) {
            col.addView(tv(t("▶ متابعة القراءة: ", "▶ Continue reading: ") + (if (isAr()) last.ar else last.en), 17f, C.WHITE, true).apply {
                background = rounded(C.DARKGREEN, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
                setOnClickListener { open(last) }
            }, lp(8))
        }

        val featured = AppConfig.FEATURED.mapNotNull { n -> l.firstOrNull { it.n == n } }
        if (featured.isNotEmpty()) {
            col.addView(tv(t("⭐ السور المختارة", "⭐ Featured Surahs"), 16f, C.DARKGREEN, true).apply { gravity = Gravity.START }, lp(12))
            featured.forEach { col.addView(row(it, true), lp(8)) }
            col.addView(tv(t("كل السور", "All Surahs"), 16f, C.DARKGREEN, true).apply { gravity = Gravity.START }, lp(20))
        }
        l.forEach { col.addView(row(it, false), lp(8)) }

        // إدارة الصوت المحفوظ
        val bytes = AudioStore.totalBytes(this) + PageStore.totalBytes(this)
        if (bytes > 0) {
            val mb = "%.1f".format(bytes / 1048576.0)
            col.addView(tv(t("🗑 مسح الصوت وصفحات المصحف المحفوظة ($mb م.ب)", "🗑 Delete saved audio & Mushaf pages ($mb MB)"), 15f, C.NAVY, true).apply {
                background = rounded(0xFFFFD9D9.toInt(), 12); setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { confirmClear() }
            }, lp(24))
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage(t("سيتم حذف كل ملفات الصوت وصفحات المصحف المحمّلة، ويمكن تحميلها مرة أخرى عند الحاجة. متابعة؟",
                "All downloaded audio and Mushaf pages will be deleted; you can download them again any time. Continue?"))
            .setPositiveButton(t("حذف", "Delete")) { _, _ ->
                startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACT_STOP))
                AudioStore.clearAll(this); PageStore.clearAll(this)
                populate()
            }
            .setNegativeButton(t("إلغاء", "Cancel"), null)
            .show()
    }

    private fun open(s: Surah) {
        startActivity(Intent(this, SurahActivity::class.java).putExtra("n", s.n))
    }

    private fun row(s: Surah, featured: Boolean): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (featured) 0xFFFFF4CC.toInt() else C.WHITE, 14)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { open(s) }
        }
        val badge = tv(num(s.n), 14f, C.WHITE, true).apply { background = rounded(C.DARKGREEN, 20); setPadding(dp(10), dp(6), dp(10), dp(6)) }
        r.addView(badge, LinearLayout.LayoutParams(dp(48), -2))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(if (isAr()) s.ar else s.en, 18f, C.NAVY, true).apply { gravity = Gravity.START })
        val sub = if (isAr()) "${s.en} • ${num(s.ayahs.size)} آية" else "${s.ar} • ${s.ayahs.size} verses"
        texts.addView(tv(sub, 13f, C.DARKGREEN).apply { gravity = Gravity.START })
        r.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        if (AudioStore.has(this, s.n)) r.addView(tv("🔊", 18f, C.NAVY))
        return r
    }
}
