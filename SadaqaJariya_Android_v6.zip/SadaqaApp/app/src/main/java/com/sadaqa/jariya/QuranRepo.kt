package com.sadaqa.jariya

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class Surah(val n: Int, val ar: String, val en: String, val ayahs: List<String>, val numbered: Boolean = true)

/** نص المصحف من assets/quran.json (يولّده tools/fetch_quran.py وقت البناء) — يعمل أوفلاين بالكامل. */
object QuranRepo {
    @Volatile private var cache: List<Surah>? = null
    @Volatile var isFull: Boolean = false
        private set

    fun load(c: Context): List<Surah> {
        cache?.let { return it }
        synchronized(this) {
            cache?.let { return it }
            val list = try {
                val txt = c.applicationContext.assets.open("quran.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
                val arr = JSONObject(txt).getJSONArray("surahs")
                val out = ArrayList<Surah>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val a = o.getJSONArray("a")
                    val l = ArrayList<String>(a.length())
                    for (j in 0 until a.length()) l.add(a.getString(j))
                    out.add(Surah(o.getInt("n"), o.getString("ar"), o.getString("en"), l))
                }
                isFull = out.size == 114
                if (out.isEmpty()) fallback() else out
            } catch (e: Throwable) {
                isFull = false
                fallback()
            }
            cache = list
            return list
        }
    }

    fun find(c: Context, n: Int): Surah? = load(c).firstOrNull { it.n == n }

    private fun fallback(): List<Surah> {
        val map = mapOf(
            "سورة الفاتحة" to Pair(1, "Al-Fatihah"),
            "سورة الإخلاص" to Pair(112, "Al-Ikhlas"),
            "سورة الفلق" to Pair(113, "Al-Falaq"),
            "سورة الناس" to Pair(114, "An-Nas")
        )
        return Content.quran.mapNotNull { it ->
            val m = map[it.title] ?: return@mapNotNull null
            Surah(m.first, it.title, m.second, listOf(it.text), numbered = false)
        }.sortedBy { it.n }
    }
}

/** ملفات الصوت: تتحمّل مرة واحدة لكل (قارئ، سورة) وتُحفظ في مساحة التطبيق الخاصة (بدون أي إذن تخزين). */
object AudioStore {
    private fun root(c: Context) = File(c.filesDir, "audio")
    fun file(c: Context, n: Int, rid: String = Prefs.reciter(c)) = File(File(root(c), rid).apply { mkdirs() }, "%03d.mp3".format(n))
    fun has(c: Context, n: Int, rid: String = Prefs.reciter(c)) = file(c, n, rid).let { it.exists() && it.length() > 10_000 }

    fun totalBytes(c: Context): Long = root(c).walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun clearAll(c: Context) { root(c).deleteRecursively() }

    fun download(c: Context, n: Int, rid: String, onProgress: (Int) -> Unit, cancelled: () -> Boolean): Boolean {
        val out = file(c, n, rid)
        val part = File(out.path + ".part")
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(AppConfig.audioUrl(rid, n)).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true
            }
            if (conn.responseCode != 200) return false
            val total = conn.contentLengthLong
            conn.inputStream.use { ins ->
                FileOutputStream(part).use { os ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        if (cancelled()) return false
                        val r = ins.read(buf)
                        if (r < 0) break
                        os.write(buf, 0, r)
                        done += r
                        if (total > 0) {
                            val pc = (done * 100 / total).toInt()
                            if (pc != last) { last = pc; onProgress(pc) }
                        }
                    }
                }
            }
            if (part.length() < 10_000) return false
            if (out.exists()) out.delete()
            return part.renameTo(out)
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
            if (part.exists()) part.delete()
        }
    }
}
