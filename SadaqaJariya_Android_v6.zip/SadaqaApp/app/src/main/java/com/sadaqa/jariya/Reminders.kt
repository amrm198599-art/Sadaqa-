package com.sadaqa.jariya

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** تذكير يومي بأذكار الصباح والمساء (محلي بالكامل بدون إنترنت). */
object Reminders {
    const val ACT = "com.sadaqa.jariya.REMIND"
    val KINDS = listOf("morning", "evening")

    private fun p(c: Context) = c.getSharedPreferences("reminders", Context.MODE_PRIVATE)
    fun enabled(c: Context, k: String) = p(c).getBoolean("on_$k", false)
    fun hour(c: Context, k: String) = p(c).getInt("h_$k", if (k == "morning") 6 else 17)
    fun minute(c: Context, k: String) = p(c).getInt("m_$k", 0)

    fun setEnabled(c: Context, k: String, on: Boolean) {
        p(c).edit().putBoolean("on_$k", on).apply()
        if (on) schedule(c, k) else cancel(c, k)
    }

    fun setTime(c: Context, k: String, h: Int, m: Int) {
        p(c).edit().putInt("h_$k", h).putInt("m_$k", m).apply()
        if (enabled(c, k)) schedule(c, k)
    }

    fun rescheduleAll(c: Context) { for (k in KINDS) if (enabled(c, k)) schedule(c, k) }

    private fun pi(c: Context, k: String): PendingIntent = PendingIntent.getBroadcast(
        c, if (k == "morning") 101 else 102,
        Intent(c, ReminderReceiver::class.java).setAction(ACT).putExtra("k", k),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun schedule(c: Context, k: String) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour(c, k)); set(Calendar.MINUTE, minute(c, k))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // غير دقيق عمدًا: لا يحتاج إذن "المنبهات الدقيقة"، وقد يتأخر دقائق مع توفير الطاقة
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(c, k))
    }

    fun cancel(c: Context, k: String) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, k))
    }

    fun timeLabel(c: Context, k: String): String {
        val h = hour(c, k); val m = minute(c, k)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "%d:%02d %s".format(h12, m, if (h < 12) c.t("ص", "AM") else c.t("م", "PM"))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Reminders.ACT -> {
                val k = i.getStringExtra("k") ?: return
                if (!Reminders.enabled(c, k)) return
                show(c, k)
                Reminders.schedule(c, k)      // الغد
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> Reminders.rescheduleAll(c)
        }
    }

    private fun show(c: Context, k: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel("reminders") == null) {
            nm.createNotificationChannel(NotificationChannel("reminders", c.t("تذكير الأذكار", "Adhkar reminders"), NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(c, 0,
            Intent(c, SectionActivity::class.java).putExtra("k", "azkar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val morning = k == "morning"
        val n = Notification.Builder(c, "reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (morning) c.t("🌅 حان وقت أذكار الصباح", "🌅 Time for the morning adhkar") else c.t("🌇 حان وقت أذكار المساء", "🌇 Time for the evening adhkar"))
            .setContentText(c.t("اضغط لقراءتها — وأجرها صدقة جارية 🤲", "Tap to read them — the reward is an ongoing charity 🤲"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(if (morning) 201 else 202, n)
    }
}
