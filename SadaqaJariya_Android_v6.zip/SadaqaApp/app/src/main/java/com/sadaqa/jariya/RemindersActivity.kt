package com.sadaqa.jariya

import android.app.Activity
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

class RemindersActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(24)) }
        col.addView(tv(t("يصلك إشعار يوميًا في الوقت الذي تحدده لقراءة الأذكار.", "Get a daily notification at the time you choose to read the adhkar."), 15f, C.DARKGREEN).apply {
            gravity = android.view.Gravity.START
        }, lp(4))
        for (k in Reminders.KINDS) addRow(col, k)
        col.addView(tv(t("قد يتأخر الإشعار بضع دقائق بسبب توفير الطاقة في الهاتف.", "The notification may be delayed a few minutes by battery saving."), 13f, C.DARKGREEN).apply {
            gravity = android.view.Gravity.START
        }, lp(16))
        setContentView(screen(t("⏰ تذكير الأذكار", "⏰ Adhkar reminders"), ScrollView(this).apply { addView(col) }))
    }

    private fun addRow(col: LinearLayout, k: String) {
        val title = if (k == "morning") t("🌅 أذكار الصباح", "🌅 Morning adhkar") else t("🌇 أذكار المساء", "🌇 Evening adhkar")
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(C.WHITE, 16); setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val timeBtn = tv(Reminders.timeLabel(this, k), 17f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener {
                TimePickerDialog(this@RemindersActivity, { _, h, m ->
                    Reminders.setTime(this@RemindersActivity, k, h, m)
                    text = Reminders.timeLabel(this@RemindersActivity, k)
                }, Reminders.hour(this@RemindersActivity, k), Reminders.minute(this@RemindersActivity, k), false).show()
            }
        }
        val sw = Switch(this).apply {
            text = title; textSize = 18f; setTextColor(C.NAVY); isChecked = Reminders.enabled(this@RemindersActivity, k)
            setOnCheckedChangeListener { _, on ->
                Reminders.setEnabled(this@RemindersActivity, k, on)
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 6)
                }
            }
        }
        card.addView(sw, lp())
        card.addView(timeBtn, lp(10))
        col.addView(card, lp(12))
    }
}
