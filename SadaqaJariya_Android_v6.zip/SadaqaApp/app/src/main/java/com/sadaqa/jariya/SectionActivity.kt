package com.sadaqa.jariya

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

class SectionActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val sec = Content.sections[intent.getStringExtra("k")]
        if (sec == null) { finish(); return }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(24)) }
        if (!isAr()) {
            col.addView(tv("Supplications and texts are shown in Arabic.", 13f, C.DARKGREEN), lp(6))
        }
        for (it in sec.items) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(C.WHITE, 16)
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            card.addView(tv(t(it.title, it.en), 16f, C.DARKGREEN, true))
            card.addView(tv(it.text, 19f, C.NAVY).apply {
                gravity = Gravity.CENTER; layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            }, lp(8))
            col.addView(card, lp(12))
        }
        setContentView(screen(t(sec.ar, sec.en), ScrollView(this).apply { addView(col) }))
    }
}
