package com.sadaqa.jariya

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class SurahActivity : Activity() {
    private lateinit var surah: Surah
    private lateinit var adapter: Adapter
    private lateinit var list: ListView
    private lateinit var content: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private lateinit var titleTv: TextView
    private lateinit var subTv: TextView
    private lateinit var bismTv: TextView
    private lateinit var nightBtn: TextView
    private lateinit var repeatBtn: TextView
    private lateinit var sleepBtn: TextView
    private val chips = mutableListOf<Pair<String, TextView>>()
    private val handler = Handler(Looper.getMainLooper())
    private var downloading = false
    private var userSeeking = false
    @Volatile private var cancelled = false
    private var fontSize = 24f
    private var night = false

    private val tick = object : Runnable {
        override fun run() {
            refreshAudioUi()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val found = QuranRepo.find(this, intent.getIntExtra("n", 0))
        if (found == null) { finish(); return }
        surah = found
        fontSize = Prefs.fontSize(this)
        night = Prefs.night(this)

        // أزرار الشريط العلوي: الوضع الليلي وحجم الخط
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun toolBtn(label: String, onClick: (TextView) -> Unit): TextView {
            val b = tv(label, 16f, C.NAVY, true).apply {
                background = rounded(C.GREEN, 10); setPadding(dp(12), dp(6), dp(12), dp(6))
            }
            b.setOnClickListener { onClick(b) }
            tools.addView(b, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6) })
            return b
        }
        nightBtn = toolBtn(if (night) "☀️" else "🌙") {
            night = !night; Prefs.setNight(this, night); it.text = if (night) "☀️" else "🌙"; applyTheme()
        }
        toolBtn("📄") { startActivity(Intent(this, MushafActivity::class.java).putExtra("page", MushafPages.startOf(surah.n))) }
        toolBtn("A-") { fontSize = (fontSize - 2f).coerceAtLeast(16f); Prefs.setFontSize(this, fontSize); adapter.notifyDataSetChanged() }
        toolBtn("A+") { fontSize = (fontSize + 2f).coerceAtMost(44f); Prefs.setFontSize(this, fontSize); adapter.notifyDataSetChanged() }

        // اختيار القارئ
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (r in AppConfig.RECITERS) {
            val c = tv(if (isAr()) r.ar else r.en, 14f, C.NAVY, true).apply { setPadding(dp(12), dp(8), dp(12), dp(8)) }
            c.setOnClickListener { Prefs.setReciter(this, r.id); styleChips(); refreshAudioUi() }
            chips.add(Pair(r.id, c))
            chipRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }

        // شريط الصوت
        playBtn = tv("", 17f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 12); setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { onPlayClick() }
        }
        status = tv("", 13f, C.DARKGREEN)
        seek = SeekBar(this).apply {
            visibility = View.GONE
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) Player.seek(p) }
                override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) { userSeeking = false }
            })
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(C.WHITE, 14)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        bar.addView(chipScroll, lp())
        bar.addView(playBtn, lp(8))
        bar.addView(seek, lp(6))
        bar.addView(status, lp(2))

        // تكرار السورة + مؤقّت النوم
        repeatBtn = tv("", 14f, C.NAVY, true).apply {
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener {
                val v = !Prefs.repeat(this@SurahActivity)
                Prefs.setRepeat(this@SurahActivity, v)
                Player.mp?.isLooping = v
                styleExtras()
            }
        }
        sleepBtn = tv(t("😴 مؤقّت النوم", "😴 Sleep timer"), 14f, C.NAVY, true).apply {
            background = rounded(0xFFEFF3F1.toInt(), 12); setPadding(dp(8), dp(10), dp(8), dp(10))
            setOnClickListener { askSleep() }
        }
        val extras = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        extras.addView(repeatBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        extras.addView(sleepBtn, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(extras, lp(8))
        styleExtras()

        // الآيات
        list = ListView(this).apply { divider = null; clipToPadding = false }
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(8)) }
        titleTv = tv(if (isAr()) surah.ar else surah.en, 26f, C.NAVY, true)
        subTv = tv((if (isAr()) surah.en else surah.ar) + " • " +
            (if (isAr()) num(surah.ayahs.size) + " آية" else surah.ayahs.size.toString() + " verses"), 13f, C.DARKGREEN)
        bismTv = tv("بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ", 24f, C.DARKGREEN, true)
        head.addView(titleTv); head.addView(subTv, lp(2))
        if (surah.n != 1 && surah.n != 9 && surah.numbered) head.addView(bismTv, lp(10))
        list.addHeaderView(head, null, false)
        adapter = Adapter()
        list.adapter = adapter

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), 0) }
        content.addView(bar, lp())
        content.addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(6) })

        setContentView(screen(if (isAr()) surah.ar else surah.en, content, tools))
        styleChips()
        applyTheme()
        if (Prefs.lastSurah(this) == surah.n) list.post { list.setSelection(Prefs.lastPos(this)) }
        refreshAudioUi()
    }

    override fun onResume() { super.onResume(); handler.post(tick) }

    override fun onPause() {
        handler.removeCallbacks(tick)
        Prefs.setLast(this, surah.n, list.firstVisiblePosition)
        super.onPause()
    }

    override fun onDestroy() {
        cancelled = true            // يلغي التحميل فقط؛ التشغيل في الخلفية يستمر عبر الخدمة
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    /* ---------- المظهر ---------- */
    private fun applyTheme() {
        val bg = if (night) 0xFF101826.toInt() else C.LIGHT
        content.setBackgroundColor(bg)
        list.setBackgroundColor(bg)
        val fg = if (night) 0xFFEDEFF4.toInt() else C.NAVY
        titleTv.setTextColor(fg)
        subTv.setTextColor(if (night) C.GREEN else C.DARKGREEN)
        bismTv.setTextColor(if (night) C.GREEN else C.DARKGREEN)
        adapter.notifyDataSetChanged()
    }

    private fun styleExtras() {
        val on = Prefs.repeat(this)
        repeatBtn.text = if (on) t("🔁 تكرار السورة: مفعّل", "🔁 Repeat: on") else t("🔁 تكرار السورة", "🔁 Repeat surah")
        repeatBtn.background = rounded(if (on) C.GREEN else 0xFFEFF3F1.toInt(), 12)
    }

    private fun askSleep() {
        if (!isMine()) {
            Toast.makeText(this, t("ابدأ التشغيل أولًا", "Start playback first"), Toast.LENGTH_SHORT).show()
            return
        }
        val mins = intArrayOf(0, 15, 30, 45, 60)
        val labels = arrayOf(t("إلغاء المؤقّت", "Turn off timer"), t("١٥ دقيقة", "15 minutes"), t("٣٠ دقيقة", "30 minutes"),
            t("٤٥ دقيقة", "45 minutes"), t("ساعة", "1 hour"))
        AlertDialog.Builder(this).setTitle(t("إيقاف التشغيل بعد", "Stop playback after"))
            .setItems(labels) { _, i ->
                startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACT_SLEEP).putExtra("min", mins[i]))
            }.show()
    }

    private fun styleChips() {
        val cur = Prefs.reciter(this)
        for ((id, c) in chips) {
            c.background = rounded(if (id == cur) C.GREEN else 0xFFEFF3F1.toInt(), 12)
        }
    }

    /* ---------- الصوت ---------- */
    private fun myKey() = Player.make(Prefs.reciter(this), surah.n)
    private fun isMine() = Player.mp != null && Player.key == myKey()

    private fun onPlayClick() {
        if (downloading) return
        val rid = Prefs.reciter(this)
        if (!AudioStore.has(this, surah.n, rid)) { startDownload(rid); return }
        if (isMine()) startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACT_TOGGLE))
        else startPlayback(rid)
        refreshAudioUi()
    }

    private fun startPlayback(rid: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 5)  // اختياري: التشغيل يعمل حتى لو رُفض
        }
        startForegroundService(Intent(this, PlayerService::class.java)
            .setAction(PlayerService.ACT_PLAY).putExtra("r", rid).putExtra("n", surah.n))
    }

    private fun startDownload(rid: String) {
        downloading = true
        refreshAudioUi()
        Thread {
            val ok = AudioStore.download(this, surah.n, rid,
                { p -> runOnUiThread { status.text = t("جارٍ التحميل… ", "Downloading… ") + p + "%" } },
                { cancelled })
            runOnUiThread {
                downloading = false
                status.text = ""
                if (ok) {
                    Toast.makeText(this, t("تم التحميل، يعمل الآن بدون إنترنت", "Downloaded — now works offline"), Toast.LENGTH_SHORT).show()
                    if (!cancelled && rid == Prefs.reciter(this)) startPlayback(rid)
                } else if (!cancelled) {
                    Toast.makeText(this, t("تعذّر التحميل، تأكد من الإنترنت أو جرّب قارئًا آخر", "Download failed — check your connection or try another reciter"), Toast.LENGTH_LONG).show()
                }
                refreshAudioUi()
            }
        }.start()
    }

    private fun refreshAudioUi() {
        val err = Player.error
        if (err != null) {
            Player.error = null
            Toast.makeText(this, t("الملف تالف، اضغط للتحميل من جديد", "Audio file is corrupt — tap to download again"), Toast.LENGTH_LONG).show()
        }
        val rid = Prefs.reciter(this)
        val mine = isMine()
        playBtn.text = when {
            downloading -> t("⏳ جارٍ التحميل…", "⏳ Downloading…")
            !AudioStore.has(this, surah.n, rid) -> t("⬇ تحميل الصوت (مرة واحدة)", "⬇ Download audio (one time)")
            mine && Player.playing() -> t("⏸ إيقاف مؤقت", "⏸ Pause")
            else -> t("▶ استماع", "▶ Play")
        }
        if (mine) {
            seek.visibility = View.VISIBLE
            val d = Player.dur()
            if (d > 0 && seek.max != d) seek.max = d
            if (!userSeeking) seek.progress = Player.pos()
            if (!downloading) {
                var txt = fmt(Player.pos()) + " / " + fmt(d)
                if (Player.sleepAt > 0) {
                    val left = ((Player.sleepAt - SystemClock.elapsedRealtime()) / 60000L).toInt() + 1
                    if (left > 0) txt += "  •  😴 " + num(left) + t(" د", " min")
                }
                status.text = txt
            }
        } else {
            seek.visibility = View.GONE
            if (!downloading) status.text = ""
        }
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /* ---------- الآيات ---------- */
    inner class Adapter : BaseAdapter() {
        override fun getCount() = surah.ayahs.size
        override fun getItem(position: Int) = surah.ayahs[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = (convertView as? TextView) ?: TextView(this@SurahActivity).apply {
                setLineSpacing(0f, 1.6f)
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                gravity = Gravity.START
                setPadding(dp(16), dp(10), dp(16), dp(10))
            }
            v.textSize = fontSize
            v.setTextColor(if (night) 0xFFEDEFF4.toInt() else C.NAVY)
            v.text = if (surah.numbered) surah.ayahs[position] + " ﴿" + (position + 1).arDigits() + "﴾" else surah.ayahs[position]
            val even = position % 2 == 0
            v.background = rounded(if (night) (if (even) 0xFF1B2638.toInt() else 0xFF16202F.toInt())
                                   else (if (even) C.WHITE else 0xFFF3FAF5.toInt()), 10)
            return v
        }
    }
}
