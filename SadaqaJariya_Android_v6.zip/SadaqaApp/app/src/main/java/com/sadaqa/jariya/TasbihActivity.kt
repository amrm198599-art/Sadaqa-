package com.sadaqa.jariya

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class TasbihActivity : Activity() {
    private val names = listOf("سبحان الله وبحمده", "أستغفر الله", "لا حول ولا قوة إلا بالله")
    private val meanings = listOf("Glory and praise be to Allah", "I seek Allah's forgiveness", "There is no might nor power except with Allah")
    private var sel = 0
    private lateinit var counter: TextView
    private lateinit var label: TextView
    private val chips = mutableListOf<TextView>()
    private val prefs by lazy { getSharedPreferences("tasbih", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, 0, dp(24)) }

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), 0) }
        names.forEachIndexed { i, n ->
            val c = tv(n, 13f, C.NAVY, true).apply {
                setPadding(dp(8), dp(10), dp(8), dp(10)); setOnClickListener { sel = i; refresh() }
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        col.addView(row, lp())

        label = tv("", 22f, C.DARKGREEN, true)
        col.addView(label, lp(28))
        counter = tv("0", 64f, C.WHITE, true).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.NAVY); setStroke(dp(6), C.GOLD) }
            setOnClickListener { prefs.edit().putInt("c$sel", prefs.getInt("c$sel", 0) + 1).apply(); refresh() }
        }
        col.addView(counter, LinearLayout.LayoutParams(dp(230), dp(230)).apply { topMargin = dp(24) })
        col.addView(tv(t("اضغط على الدائرة للعد", "Tap the circle to count"), 14f, C.DARKGREEN), lp(10))
        col.addView(tv(t("🔄 تصفير العداد", "🔄 Reset counter"), 17f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 14); setPadding(dp(24), dp(12), dp(24), dp(12))
            setOnClickListener { prefs.edit().putInt("c$sel", 0).apply(); refresh() }
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })

        setContentView(screen(t("📿 السبحة الإلكترونية", "📿 Digital Tasbih"), ScrollView(this).apply { addView(col) }))
        refresh()
    }

    private fun refresh() {
        counter.text = num(prefs.getInt("c$sel", 0))
        label.text = if (isAr()) names[sel] else names[sel] + "\n" + meanings[sel]
        chips.forEachIndexed { i, c -> c.background = rounded(if (i == sel) C.GREEN else C.WHITE, 12) }
    }
}
