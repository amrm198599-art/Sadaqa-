package com.sadaqa.jariya

import android.app.Activity
import android.content.Context
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.TextView

object C {
    const val NAVY = 0xFF0B1F3A.toInt()
    const val GREEN = 0xFFA8D5BA.toInt()
    const val LIGHT = 0xFFE8F5EC.toInt()
    const val DARKGREEN = 0xFF2E7D5B.toInt()
    const val GOLD = 0xFFD4AF37.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, r: Int = 18) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    setLineSpacing(0f, 1.35f)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

/* ---------- اللغة ---------- */
fun Context.isAr() = Prefs.lang(this) == "ar"
fun Context.t(ar: String, en: String) = if (isAr()) ar else en

fun Activity.rtl(v: View) {
    v.layoutDirection = if (isAr()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
}

fun Int.arDigits(): String {
    val d = "٠١٢٣٤٥٦٧٨٩"
    return toString().map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
}

fun Context.num(n: Int) = if (isAr()) n.arDigits() else n.toString()

/* ---------- حواف النظام (Android 15 edge-to-edge) ---------- */
fun View.onInsets(block: (Int, Int, Int, Int) -> Unit) {
    setOnApplyWindowInsetsListener { _, ins ->
        if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            block(i.left, i.top, i.right, i.bottom)
        } else {
            @Suppress("DEPRECATION")
            block(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
        }
        ins
    }
}

fun View.makeOval() {
    clipToOutline = true
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
    }
}

/** شاشة قياسية: شريط عنوان كحلي + محتوى فاتح. */
fun Activity.screen(title: String, content: View, headerExtra: View? = null): View {
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.NAVY) }
    val header = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    header.addView(tv(title, 20f, C.WHITE, true).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL },
        LinearLayout.LayoutParams(0, -2, 1f))
    if (headerExtra != null) header.addView(headerExtra)
    root.addView(header, LinearLayout.LayoutParams(-1, -2))
    content.setBackgroundColor(C.LIGHT)
    root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
    root.onInsets { l, t, r, b -> root.setPadding(l, t, r, b) }
    rtl(root)
    return root
}

private val DIAC = Regex("[\\u0610-\\u061A\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
/** تطبيع النص العربي للبحث: بدون تشكيل وبتوحيد الهمزات. */
fun String.norm(): String = DIAC.replace(this, "")
    .replace('ٱ', 'ا').replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    .replace('ى', 'ي').replace('ة', 'ه').trim().lowercase()
