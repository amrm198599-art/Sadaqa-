#!/usr/bin/env python3
"""
يحمّل نص المصحف (الرسم العثماني) مرة واحدة ويولّد app/src/main/assets/quran.json
ليُضمَّن داخل التطبيق فيعمل القرآن أوفلاين بالكامل.

التشغيل:  python3 tools/fetch_quran.py
(GitHub Actions يشغّله تلقائيًا قبل البناء)

المصدر الافتراضي: api.alquran.cloud (طبعة quran-uthmani). يمكن تغييره بمتغير QURAN_URL
بشرط أن يرجع نفس الشكل: data.surahs[].{number,name,englishName,ayahs[].text}
"""
import json, os, pathlib, re, sys, time, urllib.request

URL = os.environ.get("QURAN_URL", "https://api.alquran.cloud/v1/quran/quran-uthmani")
OUT = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/assets/quran.json"

# أعداد الآيات المتوقعة للتحقق (البقرة، الكهف، الرحمن، الدخان، الواقعة، يس، الملك)
EXPECT = {2: 286, 18: 110, 55: 78, 44: 59, 56: 96, 36: 83, 67: 30}
TOTAL_AYAHS = 6236

DIAC = re.compile(r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]")
def base(w): return DIAC.sub("", w).replace("ٱ", "ا")

def fetch():
    last = None
    for i in range(4):
        try:
            req = urllib.request.Request(URL, headers={"User-Agent": "sadaqa-jariya-build"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            last = e
            time.sleep(3 * (i + 1))
    sys.exit(f"فشل تحميل نص المصحف من {URL}: {last}")

def build(payload):
    surahs = payload["data"]["surahs"]
    out = []
    for s in surahs:
        n = s["number"]
        ay = [a["text"].strip() for a in s["ayahs"]]
        # هذه الطبعة تضع البسملة داخل أول آية في كل سورة عدا الفاتحة والتوبة: نفصلها (4 كلمات)
        if n not in (1, 9) and ay:
            w = ay[0].split(" ")
            if len(w) >= 4 and base(w[0]) == "بسم":
                rest = " ".join(w[4:]).strip()
                if rest:
                    ay[0] = rest
        out.append({"n": n, "ar": s["name"].strip(), "en": s["englishName"].strip(), "a": ay})
    return out

def validate(out):
    if len(out) != 114:
        sys.exit(f"عدد السور {len(out)} بدل 114")
    total = sum(len(s["a"]) for s in out)
    if total != TOTAL_AYAHS:
        sys.exit(f"مجموع الآيات {total} بدل {TOTAL_AYAHS}")
    by = {s["n"]: s for s in out}
    for n, c in EXPECT.items():
        if len(by[n]["a"]) != c:
            sys.exit(f"سورة {n}: {len(by[n]['a'])} آية بدل {c}")
    for s in out:
        if any(not x for x in s["a"]):
            sys.exit(f"آية فارغة في السورة {s['n']}")

def main():
    out = build(fetch())
    validate(out)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"v": 1, "surahs": out}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"تم: {len(out)} سورة، {sum(len(s['a']) for s in out)} آية -> {OUT} ({OUT.stat().st_size//1024} KB)")

if __name__ == "__main__":
    main()
