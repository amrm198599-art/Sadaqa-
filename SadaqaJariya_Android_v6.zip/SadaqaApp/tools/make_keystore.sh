#!/usr/bin/env bash
# يولّد مفتاح توقيع مرة واحدة ويطبع القيم التي تضعها في GitHub Secrets.
# احتفظ بملف release.jks وكلمات المرور في مكان آمن: لو ضاعوا لن تستطيع تحديث التطبيق على Google Play.
set -e
ALIAS="${1:-sadaqa}"
read -r -s -p "كلمة مرور المفتاح (6 أحرف على الأقل): " PASS; echo
keytool -genkeypair -v -keystore release.jks -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=Sadaqa Jariya, O=Sadaqa, C=EG"
echo
echo "=== أضف هذه الـ Secrets في GitHub (Settings > Secrets and variables > Actions) ==="
echo "KEYSTORE_BASE64   = (الناتج التالي)"
base64 -w0 release.jks 2>/dev/null || base64 release.jks | tr -d '\n'
echo; echo "KEYSTORE_PASSWORD = $PASS"
echo "KEY_ALIAS         = $ALIAS"
echo "KEY_PASSWORD      = $PASS"
