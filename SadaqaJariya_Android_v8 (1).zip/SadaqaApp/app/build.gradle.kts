plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// التوقيع: يُقرأ من متغيرات البيئة (GitHub Secrets). لو غير موجودة يُستخدم توقيع debug (للتجربة فقط).
val ksPath: String? = System.getenv("KEYSTORE_FILE")

android {
    namespace = "com.sadaqa.jariya"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sadaqa.jariya"   // غيّره لكل عميل
        minSdk = 26
        targetSdk = 35
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 2
        versionName = "2.0"
    }
    signingConfigs {
        if (ksPath != null && file(ksPath).exists()) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildFeatures { buildConfig = true }

    // نسختان: full (قابلة للتعديل، تُنشر على Google Play) و memorial (ثابتة: الشعار + اسم المرحوم، بدون زر تعديل)
    flavorDimensions += "edition"
    productFlavors {
        create("full") {
            dimension = "edition"
            buildConfigField("boolean", "EDITABLE", "true")
        }
        create("memorial") {
            dimension = "edition"
            applicationIdSuffix = ".memorial"
            versionNameSuffix = "-memorial"
            buildConfigField("boolean", "EDITABLE", "false")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }
    lint { abortOnError = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
