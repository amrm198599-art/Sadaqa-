package com.sadaqa.jariya

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

/**
 * يتيح مشاركة ملف التطبيق (APK) بدون إنترنت وبدون أي مكتبات خارجية.
 * لو وُجدت «النسخة الثابتة» داخل assets/shared (يضعها الـ workflow وقت البناء) تُرسل هي بدل التطبيق الحالي.
 */
class ApkProvider : ContentProvider() {
    companion object { const val EMBEDDED = "SadaqaJariya_Memorial.apk" }

    private fun file(): File {
        val c = context!!
        try {
            val a = c.assets.list("shared")
            if (a != null && a.contains(EMBEDDED)) {
                // اسم الملف يتغيّر مع كل تحديث للتطبيق فلا نُرسل نسخة قديمة
                val stamp = c.packageManager.getPackageInfo(c.packageName, 0).lastUpdateTime
                val out = File(c.cacheDir, "shared_" + stamp + ".apk")
                if (!out.exists() || out.length() < 100_000) {
                    c.cacheDir.listFiles()?.forEach { if (it.name.startsWith("shared_")) it.delete() }
                    c.assets.open("shared/$EMBEDDED").use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                }
                return out
            }
        } catch (e: Exception) { }
        return File(c.applicationInfo.sourceDir)
    }

    override fun onCreate() = true

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
                       selectionArgs: Array<out String>?, sortOrder: String?): Cursor? {
        val c = MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE))
        c.addRow(arrayOf<Any>("SadaqaJariya.apk", file().length()))
        return c
    }

    override fun getType(uri: Uri) = "application/vnd.android.package-archive"

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? =
        ParcelFileDescriptor.open(file(), ParcelFileDescriptor.MODE_READ_ONLY)

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
}
