package com.sadaqa.jariya

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/** إعدادات المستخدم المحفوظة على الجهاز فقط (اللغة، الاسم، الدعاء، الصورة، حجم الخط). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private fun stored(c: Context, k: String): String? = p(c).getString(k, null)?.trim()?.takeIf { it.isNotEmpty() }

    /* اللغة */
    fun lang(c: Context): String = p(c).getString("lang", "ar") ?: "ar"
    fun setLang(c: Context, v: String) { p(c).edit().putString("lang", v).apply() }

    /* النصوص */
    /** true = النسخة الثابتة: لا تعديل ولا صورة مخصّصة. */
    private fun fixed() = !BuildConfig.EDITABLE
    fun editable() = BuildConfig.EDITABLE

    fun titleAr(c: Context) = if (fixed()) AppConfig.TITLE_AR else stored(c, "titleAr") ?: AppConfig.TITLE_AR
    fun titleEn(c: Context) = if (fixed()) AppConfig.TITLE_EN else stored(c, "titleEn") ?: AppConfig.TITLE_EN
    fun nameAr(c: Context) = if (fixed()) AppConfig.FIXED_NAME_AR else stored(c, "nameAr") ?: AppConfig.NAME_AR
    fun nameEn(c: Context) = if (fixed()) AppConfig.FIXED_NAME_EN else stored(c, "nameEn") ?: stored(c, "nameAr") ?: AppConfig.NAME_EN
    fun duaAr(c: Context) = if (fixed()) AppConfig.DUA_AR else stored(c, "duaAr") ?: AppConfig.DUA_AR
    fun duaEn(c: Context) = if (fixed()) AppConfig.DUA_EN else stored(c, "duaEn") ?: stored(c, "duaAr") ?: AppConfig.DUA_EN

    fun title(c: Context) = if (c.isAr()) titleAr(c) else titleEn(c)
    fun name(c: Context) = if (c.isAr()) nameAr(c) else nameEn(c)
    fun dua(c: Context) = if (c.isAr()) duaAr(c) else duaEn(c)

    fun shareText(c: Context): String =
        if (c.isAr()) "${titleAr(c)} ${nameAr(c)}".trim() + "\nشارك التطبيق ليصله الأجر بإذن الله 🤲\nحمّل التطبيق من Google Play:"
        else "${titleEn(c)} ${nameEn(c)}".trim() + "\nShare the app so the reward reaches him, God willing 🤲\nGet it on Google Play:"

    fun saveTexts(c: Context, v: Map<String, String>) {
        val e = p(c).edit()
        for ((k, x) in v) e.putString(k, x.trim())
        e.apply()
    }

    fun resetTexts(c: Context) {
        p(c).edit().remove("titleAr").remove("titleEn").remove("nameAr").remove("nameEn")
            .remove("duaAr").remove("duaEn").apply()
    }

    /* حجم خط القرآن */
    fun fontSize(c: Context) = p(c).getFloat("fs", 24f)
    fun setFontSize(c: Context, v: Float) { p(c).edit().putFloat("fs", v).apply() }

    /* القارئ ووضع القراءة وآخر قراءة */
    fun reciter(c: Context): String = p(c).getString("reciter", AppConfig.RECITERS[0].id) ?: AppConfig.RECITERS[0].id
    fun setReciter(c: Context, id: String) { p(c).edit().putString("reciter", id).apply() }
    fun night(c: Context) = p(c).getBoolean("night", false)
    fun setNight(c: Context, v: Boolean) { p(c).edit().putBoolean("night", v).apply() }
    fun lastSurah(c: Context) = p(c).getInt("lastN", 0)
    fun lastPos(c: Context) = p(c).getInt("lastPos", 0)
    fun setLast(c: Context, n: Int, pos: Int) { p(c).edit().putInt("lastN", n).putInt("lastPos", pos).apply() }

    fun repeat(c: Context) = p(c).getBoolean("repeat", false)
    fun setRepeat(c: Context, v: Boolean) { p(c).edit().putBoolean("repeat", v).apply() }
    fun noticeHidden(c: Context) = p(c).getBoolean("noticeHidden", false)
    fun setNoticeHidden(c: Context, v: Boolean) { p(c).edit().putBoolean("noticeHidden", v).apply() }
    fun lastPage(c: Context) = p(c).getInt("lastPage", 1)
    fun setLastPage(c: Context, v: Int) { p(c).edit().putInt("lastPage", v).apply() }

    /* الصورة */
    private fun photoFile(c: Context) = File(c.filesDir, "photo.jpg")
    private fun faceFile(c: Context) = File(c.filesDir, "face.jpg")

    fun photoBitmap(c: Context): Bitmap? = if (fixed()) null else decode(photoFile(c))
    fun faceBitmap(c: Context): Bitmap? = if (fixed()) null else decode(faceFile(c))

    private fun decode(f: File): Bitmap? = try {
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    } catch (e: Throwable) { null }

    fun resetPhoto(c: Context) { photoFile(c).delete(); faceFile(c).delete() }

    /** يقرأ الصورة المختارة، يصحح الاتجاه، ويحفظ نسختين: خلفية + وجه دائري (مقصوص من أعلى المنتصف). */
    fun savePhoto(c: Context, uri: Uri): Boolean {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return false

            val rot = c.contentResolver.openInputStream(uri)?.use { rotation(it) } ?: 0
            if (rot != 0) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            }

            // الخلفية
            val scale = minOf(1f, 1280f / maxOf(bmp.width, bmp.height))
            val bg = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            FileOutputStream(photoFile(c)).use { bg.compress(Bitmap.CompressFormat.JPEG, 90, it) }

            // الوجه: الصورة كاملة بلا أي قص. تُصغَّر بحيث يدخل مستطيلها كله داخل الدائرة،
            // فوق خلفية ملوّنة ضبابية من نفس الصورة (فلا يُقصّ الوجه ولا الشعر).
            val side = 768
            val face = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
            val cv = Canvas(face)
            val soft = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            val tiny = Bitmap.createScaledBitmap(bmp, 24, 24, true)
            cv.drawBitmap(tiny, null, Rect(0, 0, side, side), soft)
            val k = 0.96 * side / Math.hypot(bmp.width.toDouble(), bmp.height.toDouble())
            val w = (bmp.width * k).toInt()
            val h = (bmp.height * k).toInt()
            val l = (side - w) / 2
            val tp = (side - h) / 2
            cv.drawBitmap(bmp, null, Rect(l, tp, l + w, tp + h), soft)
            FileOutputStream(faceFile(c)).use { face.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            return true
        } catch (e: Throwable) {
            return false
        }
    }

    private fun rotation(ins: java.io.InputStream): Int = try {
        when (ExifInterface(ins).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Throwable) { 0 }
}
