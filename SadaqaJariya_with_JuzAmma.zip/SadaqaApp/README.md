# تغيير بيانات المتوفى
1) الاسم والدعاء ونص المشاركة: app/src/main/java/com/sadaqa/jariya/AppConfig.kt
2) الصورة: استبدل res/drawable-nodpi/photo.jpg (خلفية) و photo_face.jpg (دائرية، مربعة)
3) الأيقونة: Android Studio > New > Image Asset
4) اسم التطبيق: res/values/strings.xml  |  package: app/build.gradle.kts (applicationId)
5) باقي النصوص: Content.kt
6) استيراد الأحاديث من مصدر مفتوح: python3 tools/import_hadith.py


## إضافة جزء عمّ
- تمت إضافة قسم مستقل من سورة النبأ (78) إلى سورة الناس (114)، ويضم 37 سورة.
- يلزم اتصال بالإنترنت عند فتح القسم لأول مرة لتنزيل النص؛ ثم يُحفظ محليًا ويعمل دون إنترنت.
- مصدر النص: Quran.com.ly، ملف البيانات `quran.json`: https://quran.com.ly/data
