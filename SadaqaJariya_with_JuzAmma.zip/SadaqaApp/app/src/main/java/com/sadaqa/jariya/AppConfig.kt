package com.sadaqa.jariya

import android.content.Context

/**
 * ===== كل ما تغيّره للعميل موجود هنا فقط =====
 * الصورة: استبدل الملفين في res/drawable-nodpi/
 *   photo.jpg       = الخلفية (صورة كاملة)
 *   photo_face.jpg  = الصورة الدائرية (مربعة ومقصوصة على الوجه)
 * الأيقونة: Android Studio > New > Image Asset (أو استبدل mipmap-*)
 * اسم التطبيق: res/values/strings.xml
 */
object AppConfig {
    const val TITLE = "صدقة جارية لروح المرحوم"
    const val NAME = "الحاج جلال محمد شاذلى"
    const val DUA = "اللهم اغفر له وارحمه، واجعل قبره روضة من رياض الجنة، وأنزله منزلاً مباركاً وأنت خير المنزلين"
    const val SHARE_TEXT = "صدقة جارية لروح المرحوم الحاج جلال محمد شاذلى، شارك التطبيق ليصله الأجر بإذن الله 🤲"

    val PHOTO = R.drawable.photo
    val FACE = R.drawable.photo_face

    // رابط المشاركة (يتغير تلقائيًا مع الـ package). لو عندك رابط ثابت حطه هنا.
    fun shareLink(c: Context) = "https://play.google.com/store/apps/details?id=" + c.packageName
}
