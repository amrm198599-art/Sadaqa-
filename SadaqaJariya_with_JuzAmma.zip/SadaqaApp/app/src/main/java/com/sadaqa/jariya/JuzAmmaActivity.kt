package com.sadaqa.jariya

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** جزء عمّ: تنزيل أول مرة ثم تخزين محلي للعمل دون إنترنت. */
class JuzAmmaActivity : Activity() {
    private val names = listOf(
        "النبأ", "النازعات", "عبس", "التكوير", "الانفطار", "المطففين",
        "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر",
        "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق",
        "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر",
        "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر",
        "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس"
    )
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("juz_amma_cache", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.LIGHT)
        }
        root.addView(tv("📗 جزء عمّ", 22f, C.WHITE, true).apply {
            setBackgroundColor(C.NAVY)
            setPadding(dp(16), dp(18), dp(16), dp(18))
        }, lp())
        status = tv("جارٍ تجهيز جزء عمّ...", 15f, C.DARKGREEN)
        root.addView(status, lp(10))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(content) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        rtl(root)
        setContentView(root)

        val cached = prefs.getString("juz_json", null)
        if (!cached.isNullOrBlank()) {
            showSurahList(JSONObject(cached))
            status.text = "متاح دون إنترنت • ٣٧ سورة"
        } else {
            status.text = "يلزم الاتصال بالإنترنت أول مرة لتنزيل النص وحفظه."
            downloadJuz()
        }
    }

    private fun downloadJuz() {
        status.text = "جارٍ تنزيل جزء عمّ لأول مرة..."
        thread {
            try {
                val connection = URL("https://quran.com.ly/assets/data/quran.json")
                    .openConnection() as HttpURLConnection
                connection.connectTimeout = 20000
                connection.readTimeout = 30000
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                connection.disconnect()
                val source = JSONArray(body)
                val grouped = JSONObject()
                for (i in 0 until source.length()) {
                    val verse = source.getJSONObject(i)
                    val surah = verse.optInt("sura", verse.optInt("s"))
                    if (surah !in 78..114) continue
                    val number = verse.optInt("aya", verse.optInt("a"))
                    val text = verse.optString("text", verse.optString("ar"))
                    if (text.isBlank()) continue
                    val key = surah.toString()
                    val verses = if (grouped.has(key)) grouped.getJSONArray(key)
                        else JSONArray().also { grouped.put(key, it) }
                    verses.put(JSONObject().put("number", number).put("text", text))
                }
                if (grouped.length() != 37) error("لم يكتمل تنزيل السور")
                prefs.edit().putString("juz_json", grouped.toString()).apply()
                runOnUiThread {
                    status.text = "تم حفظ جزء عمّ على جهازك • يعمل دون إنترنت"
                    showSurahList(grouped)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "تعذّر التنزيل. تأكد من الإنترنت ثم أعد المحاولة."
                    content.removeAllViews()
                    content.addView(tv("اضغط لإعادة المحاولة بعد التأكد من اتصال الإنترنت.", 17f, C.NAVY))
                    content.addView(tv("إعادة المحاولة", 17f, C.WHITE, true).apply {
                        background = rounded(C.DARKGREEN, 12)
                        setPadding(dp(16), dp(14), dp(16), dp(14))
                        setOnClickListener { downloadJuz() }
                    }, lp(12))
                }
            }
        }
    }

    private fun showSurahList(data: JSONObject) {
        content.removeAllViews()
        for (i in names.indices) {
            val surahNumber = i + 78
            val count = data.optJSONArray(surahNumber.toString())?.length() ?: 0
            content.addView(tv("${surahNumber.toString().padStart(2, '0')}  •  سورة ${names[i]}  •  $count آية", 17f, C.NAVY, true).apply {
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                background = rounded(C.WHITE, 14)
                setPadding(dp(16), dp(15), dp(16), dp(15))
                setOnClickListener { showSurah(data, surahNumber, names[i]) }
            }, lp(9))
        }
    }

    private fun showSurah(data: JSONObject, number: Int, name: String) {
        content.removeAllViews()
        content.addView(tv("‹  الرجوع إلى فهرس السور", 16f, C.DARKGREEN, true).apply {
            gravity = Gravity.RIGHT
            setPadding(dp(8), dp(12), dp(8), dp(12))
            setOnClickListener { showSurahList(data) }
        })
        content.addView(tv("سورة $name", 23f, C.DARKGREEN, true), lp(8))
        val verses = data.optJSONArray(number.toString()) ?: JSONArray()
        val joined = StringBuilder()
        for (i in 0 until verses.length()) {
            val verse = verses.getJSONObject(i)
            joined.append(verse.optString("text"))
                .append(" ﴿").append(verse.optInt("number")).append("﴾  ")
        }
        content.addView(tv(joined.toString(), 23f, C.NAVY).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(18), dp(10), dp(24))
            textDirection = View.TEXT_DIRECTION_RTL
            setLineSpacing(dp(10).toFloat(), 1.35f)
        }, lp(12))
    }
}
