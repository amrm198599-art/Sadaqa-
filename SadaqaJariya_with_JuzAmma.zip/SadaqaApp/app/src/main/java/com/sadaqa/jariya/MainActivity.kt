package com.sadaqa.jariya

import android.app.Activity
import android.content.Intent
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(AppConfig.PHOTO); scaleType = ImageView.ScaleType.CENTER_CROP
        }, ViewGroup.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(0xD00B1F3A.toInt()) }, ViewGroup.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(32))
        }
        val ring = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C.GOLD) }
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        ring.addView(ImageView(this).apply {
            setImageResource(AppConfig.FACE); scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }, FrameLayout.LayoutParams(dp(170), dp(170)))
        col.addView(ring, LinearLayout.LayoutParams(-2, -2))

        col.addView(tv(AppConfig.TITLE, 16f, C.GREEN), lp(18))
        col.addView(tv(AppConfig.NAME, 28f, C.WHITE, true), lp(4))
        col.addView(tv(AppConfig.DUA, 17f, C.LIGHT).apply {
            background = rounded(0x33FFFFFF, 16); setPadding(dp(16), dp(14), dp(16), dp(14))
        }, lp(16))

        fun btn(label: String, bg: Int = C.LIGHT, fg: Int = C.NAVY, onClick: () -> Unit) {
            col.addView(tv(label, 18f, fg, true).apply {
                background = rounded(bg, 14); setPadding(dp(12), dp(14), dp(12), dp(14))
                setOnClickListener { onClick() }
            }, lp(12))
        }
        fun open(k: String) = { startActivity(Intent(this, SectionActivity::class.java).putExtra("k", k)); Unit }

        val link = AppConfig.shareLink(this)
        btn("📤 شارك التطبيق لزيادة الأجر", C.GOLD) {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, AppConfig.SHARE_TEXT + "\n" + link)
            }, "مشاركة التطبيق"))
        }
        btn("📖 القرآن الكريم", onClick = open("quran"))
        btn("📗 جزء عمّ كاملًا") { startActivity(Intent(this, JuzAmmaActivity::class.java)) }
        btn("🌅 أذكار الصباح والمساء", onClick = open("azkar"))
        btn("🛡️ حصن المسلم", onClick = open("hisn"))
        btn("🤲 أدعية للمتوفى", onClick = open("dua"))
        btn("📿 السبحة الإلكترونية") { startActivity(Intent(this, TasbihActivity::class.java)) }
        btn("📜 الأحاديث النبوية", onClick = open("hadith"))

        root.addView(ScrollView(this).apply { addView(col) })
        rtl(root); setContentView(root)
    }
}
