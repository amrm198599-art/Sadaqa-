package com.sadaqa.jariya

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class SectionActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val (title, items) = Content.sections[intent.getStringExtra("k")] ?: return finish()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.LIGHT) }
        root.addView(tv(title, 20f, C.WHITE, true).apply {
            setBackgroundColor(C.NAVY); setPadding(dp(16), dp(16), dp(16), dp(16))
        }, lp())
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(24)) }
        for (it in items) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(C.WHITE, 16)
                setPadding(dp(16), dp(14), dp(16), dp(14))
            }
            card.addView(tv(it.title, 16f, C.DARKGREEN, true))
            card.addView(tv(it.text, 19f, C.NAVY).apply { gravity = Gravity.CENTER }, lp(8))
            col.addView(card, lp(12))
        }
        root.addView(ScrollView(this).apply { addView(col) })
        rtl(root); setContentView(root)
    }
}
