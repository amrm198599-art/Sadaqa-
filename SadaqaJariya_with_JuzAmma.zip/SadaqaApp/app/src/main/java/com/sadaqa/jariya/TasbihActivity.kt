package com.sadaqa.jariya

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class TasbihActivity : Activity() {
    private val names = listOf("سبحان الله وبحمده", "أستغفر الله", "لا حول ولا قوة إلا بالله")
    private var sel = 0
    private lateinit var counter: TextView
    private lateinit var label: TextView
    private val chips = mutableListOf<TextView>()
    private val prefs by lazy { getSharedPreferences("tasbih", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(C.LIGHT); gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(tv("📿 السبحة الإلكترونية", 20f, C.WHITE, true).apply {
            setBackgroundColor(C.NAVY); setPadding(dp(16), dp(16), dp(16), dp(16))
        }, lp())

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(16), dp(8), 0) }
        names.forEachIndexed { i, n ->
            val c = tv(n, 13f, C.NAVY, true).apply {
                setPadding(dp(8), dp(10), dp(8), dp(10)); setOnClickListener { sel = i; refresh() }
            }
            chips.add(c)
            row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        root.addView(row, lp())

        label = tv("", 22f, C.DARKGREEN, true)
        root.addView(label, lp(28))
        counter = tv("0", 64f, C.WHITE, true).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(C.NAVY); setStroke(dp(6), C.GOLD)
            }
            setOnClickListener { prefs.edit().putInt("c$sel", prefs.getInt("c$sel", 0) + 1).apply(); refresh() }
        }
        root.addView(counter, LinearLayout.LayoutParams(dp(230), dp(230)).apply { topMargin = dp(24) })
        root.addView(tv("اضغط على الدائرة للعد", 14f, C.DARKGREEN), lp(10))
        root.addView(tv("🔄 تصفير العداد", 17f, C.WHITE, true).apply {
            background = rounded(C.DARKGREEN, 14); setPadding(dp(24), dp(12), dp(24), dp(12))
            setOnClickListener { prefs.edit().putInt("c$sel", 0).apply(); refresh() }
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        rtl(root); setContentView(root); refresh()
    }

    private fun refresh() {
        counter.text = prefs.getInt("c$sel", 0).toString()
        label.text = names[sel]
        chips.forEachIndexed { i, c -> c.background = rounded(if (i == sel) C.GREEN else C.WHITE, 12) }
    }
}
