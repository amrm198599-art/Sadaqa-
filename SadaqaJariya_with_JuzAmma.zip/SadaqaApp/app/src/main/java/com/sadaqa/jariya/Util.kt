package com.sadaqa.jariya

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    const val NAVY = 0xFF0B1F3A.toInt()
    const val GREEN = 0xFFA8D5BA.toInt()
    const val LIGHT = 0xFFE8F5EC.toInt()
    const val DARKGREEN = 0xFF2E7D5B.toInt()
    const val GOLD = 0xFFD4AF37.toInt()
    const val WHITE = 0xFFFFFFFF.toInt()
}

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.rounded(color: Int, r: Int = 18) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat()
}

fun Context.tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    setLineSpacing(0f, 1.35f)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

fun Activity.rtl(v: View) { v.layoutDirection = View.LAYOUT_DIRECTION_RTL }
