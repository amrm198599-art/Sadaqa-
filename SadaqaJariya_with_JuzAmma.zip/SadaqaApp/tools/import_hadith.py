#!/usr/bin/env python3
"""
يستورد الأحاديث من مصدر مفتوح (fawazahmed0/hadith-api) ويولّد HadithData.kt
التشغيل (على جهازك، يحتاج إنترنت):   python3 tools/import_hadith.py
ثم راجع الناتج في الشاشة قبل النشر.
"""
import json, re, sys, urllib.request, pathlib
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")

EDITIONS = ["ara-muslim", "ara-bukhari", "ara-abudawud", "ara-tirmidhi", "ara-ibnmajah"]
BASES = ["https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/{e}.min.json",
         "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/{e}.json",
         "https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/editions/{e}.min.json",
         "https://raw.githubusercontent.com/fawazahmed0/hadith-api/1/editions/{e}.json"]

# (العنوان, عبارة بحث من نص الحديث)
WANTED = [
 ("الصدقة الجارية", "انقطع عنه عمله إلا من ثلاثة"),
 ("الدال على الخير", "من دل على خير فله مثل أجر فاعله"),
 ("من سنّ سنة حسنة", "من سن في الإسلام سنة حسنة"),
 ("ما يلحق المؤمن بعد موته", "إن مما يلحق المؤمن من عمله وحسناته بعد موته"),
 ("رفع الدرجات بالاستغفار", "باستغفار ولدك لك"),
 ("الدعاء للميت بعد دفنه", "استغفروا لأخيكم وسلوا له بالتثبيت"),
 ("الصدقة تطفئ الخطيئة", "الصدقة تطفئ الخطيئة"),
 ("اتقوا النار", "اتقوا النار ولو بشق تمرة"),
]

def norm(t):
    t = re.sub(r"[\u064B-\u065F\u0670\u0640]", "", t)
    t = re.sub(r"[إأآٱ]", "ا", t).replace("ى", "ي").replace("ة", "ه")
    return re.sub(r"\s+", " ", t).strip()

def load(e):
    for u in BASES:
        try:
            with urllib.request.urlopen(u.format(e=e), timeout=60) as r:
                return json.load(r)
        except Exception as ex:
            print("  فشل", u.format(e=e), ex, file=sys.stderr)
    return None

def matn(t):  # حذف السند تقريبًا: ابدأ من أول "قال رسول الله" أو "أن رسول الله"
    m = re.search(r"(قال رسول الله|أن رسول الله|أنه قال|عن النبي)", t)
    return t[m.start():] if m else t

def ktr(s): return s.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("\n", " ")

data = {}
for e in EDITIONS:
    print("تحميل", e); d = load(e)
    if d: data[e] = [(h, norm(h.get("text", ""))) for h in d["hadiths"]]

out, seen = [], set()
for title, phrase in WANTED:
    q = norm(phrase); hit = None
    for e, hs in data.items():
        for h, n in hs:
            if q in n: hit = (e, h); break
        if hit: break
    if not hit: print("✗ لم يُعثر على:", title); continue
    e, h = hit
    key = (e, h.get("hadithnumber"))
    if key in seen: continue
    seen.add(key)
    grades = "، ".join(f'{g.get("grade")} ({g.get("name")})' for g in h.get("grades", []) if g.get("grade"))
    src = f'{e.replace("ara-", "")} رقم {h.get("hadithnumber")}' + (f' — الدرجة: {grades}' if grades else "")
    text = matn(h["text"]).strip()
    print(f"✓ {title}\n   {text[:120]}…\n   [{src}]\n")
    out.append(f'        Item("{ktr(title)}", "{ktr(text)} \\n[{ktr(src)}]")')

path = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/java/com/sadaqa/jariya/HadithData.kt"
path.write_text('package com.sadaqa.jariya\n\n/** مُولَّد من hadith-api (fawazahmed0). راجعه قبل النشر. */\nobject HadithData {\n    val items = listOf(\n' + ",\n".join(out) + '\n    )\n}\n', encoding="utf-8")
print("تم الكتابة في", path)
